---
name: arxiv-research-brief
description: Use when the user asks to search arXiv, find recent or date-bounded papers, track research directions, query specific arXiv IDs or links, generate briefs for selected arXiv papers, search by keywords/categories, or avoid repeating previously recommended papers.
---

# arXiv Research Brief

Use the official arXiv Atom API to retrieve metadata and abstracts for bounded searches or direct arXiv ID/link lookups, then write concise research briefs in the fixed report format. Never use `arxivsub-skill` in this workflow.

## Non-negotiable boundaries

- Read titles, complete abstracts, and metadata only.
- Do not download, open, OCR, summarize, or inspect PDFs or full text.
- In search mode, do not fill a quota with papers below the relevance threshold.
- In direct lookup mode, include every valid user-specified paper returned by arXiv.
- Do not guess a conference or journal.
- Return the complete brief in the conversation. A file path is never the final answer.
- Treat script scores as pre-screening signals, not final academic judgment.

## Resolve the request

Map time expressions as follows unless the user supplies exact dates:

| User phrase | Window |
|---|---:|
| 本周 / 近期 / this week / recent | 7 days |
| 近一个月 / this month | 30 days |
| 近三个月 / this quarter | 90 days |
| 近一年 / this year | 365 days |

Use explicit `--start YYYY-MM-DD --end YYYY-MM-DD` when exact dates are given. Exact dates override relative wording.

Choose one workflow first:

- Direct lookup: when the user provides arXiv IDs or links, use `lookup`. Supported inputs include `arxiv.org/abs/...`, `arxiv.org/html/...`, `arxiv.org/pdf/...`, `arXiv:2204.05381v4`, and bare IDs such as `2204.05381`.
- Search mode: when the user asks for papers by topic, keywords, categories, time window, profile, or weekly/date-bounded monitoring, use `search`.

For search mode, choose one search configuration:

- Default multimodal brief: `--profile multimodal`.
- Reusable multi-topic brief: `--profile-file <CONFIG_PATH>`.
- One topic: use `--query`, or one or more `--keyword` values, plus optional filters.

The built-in multimodal profile covers:

1. 多模态表征学习
2. 多模态融合策略
3. 不完整多模态学习
4. 不确定性感知多模态融合
5. 多模态蒸馏

Read [profile-schema.md](references/profile-schema.md) only when creating or reviewing a custom profile.

## Retrieve bounded candidates

Use this section for search mode.

Create a workspace-local temporary directory such as:

```text
<PROJECT_ROOT>/tmp/codex-session-arxiv-research-brief/
```

Run the bundled CLI with the active Python interpreter:

```text
<PYTHON_EXE> <SKILL_ROOT>/scripts/arxiv_brief.py search --profile multimodal --days 7 --candidate-limit 8 --papers-per-topic 3 --output <TMP_DIR>/candidates.json
```

Single-topic example:

```text
<PYTHON_EXE> <SKILL_ROOT>/scripts/arxiv_brief.py search --name "Multimodal Distillation" --keyword "multimodal distillation" --required-group "multimodal|multi-modal|cross-modal" --required-group "distillation|teacher-student" --positive "multimodal distillation=12" --days 30 --output <TMP_DIR>/candidates.json
```

Use `--start` and `--end` instead of `--days` for a custom range. Run `--help` for the full CLI. Do not read cache files: read only the produced candidate JSON.

The CLI:

- adds an exact `submittedDate` range;
- paginates with `start` and `max_results`;
- waits at least about three seconds between network requests;
- retries timeouts, HTTP 429, and server errors;
- caches identical API pages for 24 hours under the workspace `tmp` directory;
- reports truncation and per-topic failures;
- deduplicates arXiv versions;
- separates relevance, evidence hints, and recency;
- emits at most `candidate-limit` complete abstracts per topic.

## Look up specified arXiv papers

Use this section when the user supplies one or more arXiv IDs or links. Do not use keyword relevance filters for direct lookup.

```text
<PYTHON_EXE> <SKILL_ROOT>/scripts/arxiv_brief.py lookup <ARXIV_ID_OR_URL...> --output <TMP_DIR>/candidates.json
```

The lookup command:

- normalizes arXiv `abs`, `html`, and `pdf` links, `arXiv:` prefixes, versioned IDs, and bare IDs;
- queries the official Atom API with `id_list`;
- uses the same cache, retry, timeout, and metadata parser as search mode;
- preserves user input order in the emitted candidates;
- puts unrecognized or not-returned inputs in `missing_inputs`;
- emits one topic named `指定 arXiv 论文`;
- does not rank, threshold, or drop valid user-specified papers.

## Review abstracts and select papers

Read every emitted candidate's title, complete abstract, metadata, relevance reasons, and evidence hints. For direct lookup, read every returned paper. For each topic:

1. Reject semantic false positives even if their lexical score is high.
2. Identify the research problem, core method, abstract-level evidence, reading value, and limitations.
3. For every selected paper, extract enough substance for a reader to understand the work without opening arXiv:
   - the task background or application setting;
   - the concrete gap, failure mode, or research question;
   - the paper's main insight or motivation when the abstract makes it clear: what contradiction, bottleneck, or overlooked signal did the authors notice, and why does that make their solution natural;
   - a concise insight judgment in plain research logic: "the authors turn <task difficulty> into <method idea>";
   - the core innovation and how the proposed method works at a high level;
   - the transferable lesson a reader could learn even if the paper's exact task or algorithm family is unfamiliar;
   - the abstract-level validation evidence and what it does or does not prove.
4. In search mode, select at most `requested_papers`; select fewer when evidence or relevance is weak. In direct lookup mode, include all valid user-specified papers returned by arXiv.
5. Put `history_status: updated` papers in the important-update section.
6. Use recency only to break otherwise similar relevance, not as a substitute for relevance.

Do not compress selected-paper cards into one-line explanations. Preserve the report headings and card fields, but make the content inside `研究问题`, `核心方法`, `摘要证据`, `阅读建议`, and `风险与局限` detailed enough to teach what the paper is doing and why the authors' idea is worth learning. Avoid merely translating abstract terminology into Chinese; explain the research logic from problem tension to insight to method design.

For a final selection that explicitly contains a DOI, `journal_ref`, or a clear venue statement in `comment`, use `check-paper-oa` if available. Enrich only those selected papers. If matching is ambiguous, retain the raw arXiv declaration and state that the venue is unconfirmed.

## Write and validate the brief

Read [report-format.md](references/report-format.md) before drafting. Follow its headings and card fields exactly.

Use a trend statement only when at least two selected papers support it. State retrieval errors, truncation, and lookup `missing_inputs` explicitly. Preserve abstract-page links.

For a non-trivial report, write the draft temporarily, validate it, then paste the complete validated content into the final response:

```text
<PYTHON_EXE> <SKILL_ROOT>/scripts/arxiv_brief.py validate-report --input <TMP_DIR>/brief.md --topic "<TOPIC_1>" --topic "<TOPIC_2>"
```

Delete the temporary report after it is no longer needed. Keep the 24-hour API cache unless the user asks to clear it.

## Optional history

History is opt-in and stored only at a user-selected path. Pass `--history-file <PATH>` during search to hide unchanged papers already recommended. Updated arXiv versions remain visible.

After the final selection, record only papers actually recommended:

```text
<PYTHON_EXE> <SKILL_ROOT>/scripts/arxiv_brief.py history mark --history-file <PATH> --paper "<TOPIC_ID>=<ARXIV_ID>"
```

Use `history filter` to apply a history file to an existing candidate JSON. Never mark all retrieved candidates automatically.

Run `history clear --history-file <PATH> --paper <ARXIV_ID>` or `--all` only when the user explicitly asks to remove history.

## Failure handling

- If one topic fails, continue with the other topics and show the error in that section.
- If every topic fails, report the API or network failure and do not fabricate a brief.
- If results are truncated, state the configured fetch limit.
- If direct lookup has invalid or not-returned inputs, list them without fabricating paper metadata.
- If no paper passes the threshold, say so directly.
- If all active topics return zero raw hits, or raw hits exist but no eligible candidates pass the relevance threshold, stop after retrieval. Do not broaden queries, extend the date window, switch topics, or fill the brief with weak matches unless the user explicitly asks for a looser retry. Report the exact date window, active query/profile, and zero-result or zero-candidate status.
- In multi-topic briefs, a zero-result topic does not stop other topics. Continue with topics that have eligible candidates, and mark only the empty topic as having no qualifying papers.
- If the official API is unavailable, do not silently switch to a third-party paper service.
- For default weekly briefs, call the bundled CLI default path directly: `arxiv_brief.py search --profile multimodal ...`. Do not use workspace files, `tmp/`, or previous run artifacts unless the user explicitly asks to reuse a specific local config.
