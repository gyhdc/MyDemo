from __future__ import annotations

import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
import xml.etree.ElementTree as ET
from contextlib import redirect_stdout
from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory


SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from arxiv_research_brief.adapters import (
    ArxivApiError,
    ArxivOfficialAdapter,
    ArxivQueryError,
)
from arxiv_research_brief.cache import ResponseCache
import arxiv_research_brief.cli as cli_module
from arxiv_research_brief.cli import main, normalize_arxiv_identifier
from arxiv_research_brief.history import HistoryStore
from arxiv_research_brief.models import (
    AdapterSearchResult,
    PaperRecord,
    TopicSpec,
)
from arxiv_research_brief.pipeline import BriefPipeline, deduplicate_versions
from arxiv_research_brief.profiles import build_custom_topic, load_profile
from arxiv_research_brief.query import DateWindow, build_search_query
from arxiv_research_brief.ranking import rank_papers
from arxiv_research_brief.report_validation import validate_report
from arxiv_research_brief.xml_parser import parse_atom_feed


def atom_feed(
    entries: list[tuple[str, str, str]],
    total: int | None = None,
    start: int = 0,
) -> bytes:
    entry_xml = []
    for source_id, title, abstract in entries:
        entry_xml.append(
            f"""
  <entry>
    <id>http://arxiv.org/abs/{source_id}</id>
    <updated>2026-06-24T00:00:00Z</updated>
    <published>2026-06-20T00:00:00Z</published>
    <title>{title}</title>
    <summary>{abstract}</summary>
    <author>
      <name>Alice</name>
      <arxiv:affiliation>Example University</arxiv:affiliation>
    </author>
    <category term="cs.CV"/>
    <category term="cs.LG"/>
    <arxiv:primary_category term="cs.CV"/>
    <arxiv:comment>Accepted at ExampleConf 2026</arxiv:comment>
    <arxiv:journal_ref>ExampleConf 2026</arxiv:journal_ref>
    <arxiv:doi>10.1000/example</arxiv:doi>
    <link rel="alternate" href="http://arxiv.org/abs/{source_id}"/>
    <link title="pdf" href="http://arxiv.org/pdf/{source_id}"/>
  </entry>"""
        )
    count = len(entries)
    return f"""\
<feed xmlns="http://www.w3.org/2005/Atom"
      xmlns:arxiv="http://arxiv.org/schemas/atom"
      xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
  <opensearch:totalResults>{count if total is None else total}</opensearch:totalResults>
  <opensearch:startIndex>{start}</opensearch:startIndex>
  <opensearch:itemsPerPage>{count}</opensearch:itemsPerPage>
  {''.join(entry_xml)}
</feed>
""".encode("utf-8")


class FakeResponse:
    def __init__(self, payload: bytes) -> None:
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def read(self) -> bytes:
        return self.payload


def make_paper(
    source_id: str = "2606.00001v1",
    title: str = "Uncertainty-Aware Multimodal Fusion",
    abstract: str = (
        "We propose uncertainty-aware multimodal fusion. "
        "Experiments on three datasets include ablations."
    ),
) -> PaperRecord:
    return PaperRecord(
        source="arxiv",
        source_id=source_id,
        title=title,
        abstract=abstract,
        authors=["Alice"],
        affiliations=["Example University"],
        published="2026-06-20T00:00:00Z",
        updated="2026-06-20T00:00:00Z",
        primary_category="cs.CV",
        categories=["cs.CV", "cs.LG"],
        abstract_url=f"https://arxiv.org/abs/{source_id}",
        pdf_url=f"https://arxiv.org/pdf/{source_id}",
        comment="Accepted at ExampleConf 2026",
        journal_ref="ExampleConf 2026",
        doi="10.1000/example",
    )


def make_topic() -> TopicSpec:
    return TopicSpec(
        id="uncertainty",
        name="不确定性感知多模态融合",
        query='all:"multimodal fusion"',
        required_groups=[
            ["multimodal", "multi-modal"],
            ["uncertainty", "evidential"],
            ["fusion", "integration"],
        ],
        positive_terms={
            "uncertainty-aware": 8,
            "multimodal fusion": 8,
        },
        negative_terms={"survey": -4},
        exclude_terms=["nuclear fusion"],
        categories=["cs.CV"],
        min_score=7,
    )


class DateAndQueryTests(unittest.TestCase):
    def test_exact_date_query(self):
        window = DateWindow.from_values(
            start="2026-06-01",
            end="2026-06-25",
            today=date(2026, 6, 25),
        )
        query = build_search_query('all:"multimodal fusion"', window, ["cs.CV"])
        self.assertIn("submittedDate:[202606010000 TO 202606252359]", query)
        self.assertIn("(cat:cs.CV)", query)

    def test_relative_window_is_inclusive(self):
        window = DateWindow.from_values(days=7, today=date(2026, 6, 25))
        self.assertEqual(window.start.isoformat(), "2026-06-19")
        self.assertEqual(window.end.isoformat(), "2026-06-25")
        self.assertEqual(window.days, 7)

    def test_invalid_date_combinations_are_rejected(self):
        with self.assertRaises(ValueError):
            DateWindow.from_values(days=7, start="2026-06-01", end="2026-06-02")
        with self.assertRaises(ValueError):
            DateWindow.from_values(start="2026-06-01")
        with self.assertRaises(ValueError):
            DateWindow.from_values(start="2026-06-02", end="2026-06-01")


class ParsingAndRankingTests(unittest.TestCase):
    def test_normalize_arxiv_identifier_variants(self):
        cases = {
            "https://arxiv.org/abs/2204.05381": "2204.05381",
            "https://arxiv.org/html/2309.05300v3": "2309.05300v3",
            "https://arxiv.org/pdf/2204.01678.pdf": "2204.01678",
            "arXiv:2204.05381v4": "2204.05381v4",
            "2204.01678": "2204.01678",
        }
        for raw, expected in cases.items():
            self.assertEqual(normalize_arxiv_identifier(raw), expected)

    def test_parser_preserves_extended_metadata(self):
        root = ET.fromstring(
            atom_feed(
                [
                    (
                        "2606.00001v2",
                        "Uncertainty-Aware Multimodal Fusion",
                        "Experiments on three datasets include ablations.",
                    )
                ],
                total=2,
            )
        )
        page = parse_atom_feed(root)
        paper = page.items[0]
        self.assertEqual(page.total_results, 2)
        self.assertEqual(paper.source_id, "2606.00001v2")
        self.assertEqual(paper.doi, "10.1000/example")
        self.assertEqual(paper.affiliations, ["Example University"])
        self.assertEqual(paper.categories, ["cs.CV", "cs.LG"])
        self.assertTrue(paper.abstract_url.startswith("https://"))

    def test_version_dedup_keeps_latest(self):
        old = make_paper("2606.00001v1")
        new = make_paper("2606.00001v2")
        new.updated = "2026-06-24T00:00:00Z"
        unique = deduplicate_versions([old, new])
        self.assertEqual(len(unique), 1)
        self.assertEqual(unique[0].source_id, "2606.00001v2")

    def test_ranking_rejects_missing_required_concept(self):
        good = make_paper()
        weak = make_paper(
            "2606.00002v1",
            "Multimodal Representation Learning",
            "We learn multimodal representations.",
        )
        ranked = rank_papers([good, weak], make_topic(), candidate_limit=8)
        self.assertEqual([item.paper.source_id for item in ranked], [good.source_id])
        self.assertIn("datasets", ranked[0].evidence_hint)
        self.assertIn("ablation", ranked[0].evidence_hint)

    def test_hard_exclusion_beats_positive_keywords(self):
        paper = make_paper()
        paper.abstract += " This is a nuclear fusion survey."
        ranked = rank_papers([paper], make_topic(), candidate_limit=8)
        self.assertEqual(ranked, [])


class CacheAndAdapterTests(unittest.TestCase):
    def test_cache_ttl_and_cleanup(self):
        with TemporaryDirectory() as temp:
            cache = ResponseCache(Path(temp), ttl_seconds=10)
            cache.set("key", b"value", now=100)
            self.assertEqual(cache.get("key", now=105), b"value")
            self.assertIsNone(cache.get("key", now=111))
            self.assertEqual(cache.cleanup(now=111), 0)

    def test_adapter_paginates_and_uses_only_official_endpoint(self):
        payloads = [
            atom_feed(
                [("2606.00001v1", "Uncertainty Multimodal Fusion", "Experiments.")],
                total=2,
                start=0,
            ),
            atom_feed(
                [("2606.00002v1", "Evidential Multimodal Fusion", "Evaluation.")],
                total=2,
                start=1,
            ),
        ]
        urls: list[str] = []

        def transport(request, timeout):
            urls.append(request.full_url)
            return FakeResponse(payloads.pop(0))

        adapter = ArxivOfficialAdapter(
            transport=transport,
            request_interval_seconds=0,
        )
        result = adapter.search(
            make_topic(),
            DateWindow.from_values(days=7, today=date(2026, 6, 25)),
            page_size=1,
            max_results=2,
            max_pages=3,
        )
        self.assertEqual(len(result.items), 2)
        self.assertEqual(result.pages_fetched, 2)
        self.assertFalse(result.truncated)
        self.assertTrue(
            all(url.startswith("https://export.arxiv.org/api/query?") for url in urls)
        )

    def test_adapter_reuses_cached_page(self):
        with TemporaryDirectory() as temp:
            cache = ResponseCache(Path(temp))
            calls = 0

            def transport(request, timeout):
                nonlocal calls
                calls += 1
                return FakeResponse(atom_feed([], total=0))

            window = DateWindow.from_values(days=7, today=date(2026, 6, 25))
            first = ArxivOfficialAdapter(
                cache=cache,
                transport=transport,
                request_interval_seconds=0,
            )
            first.search(make_topic(), window, 10, 10, 1)
            second = ArxivOfficialAdapter(
                cache=cache,
                transport=transport,
                request_interval_seconds=0,
            )
            result = second.search(make_topic(), window, 10, 10, 1)
            self.assertEqual(calls, 1)
            self.assertEqual(result.cached_pages, 1)

    def test_adapter_lookup_by_ids_uses_id_list(self):
        urls: list[str] = []

        def transport(request, timeout):
            urls.append(request.full_url)
            return FakeResponse(
                atom_feed(
                    [
                        (
                            "2204.05381v4",
                            "Self-supervised Vision Transformers",
                            "We learn SAR optical representations.",
                        )
                    ],
                    total=1,
                )
            )

        adapter = ArxivOfficialAdapter(
            transport=transport,
            request_interval_seconds=0,
        )
        result = adapter.lookup_by_ids(["2204.05381"])
        self.assertEqual(result.items[0].source_id, "2204.05381v4")
        decoded_url = urllib.parse.unquote(urls[0])
        self.assertIn("id_list=2204.05381", decoded_url)
        self.assertNotIn("search_query", decoded_url)

    def test_adapter_lookup_by_ids_reuses_cache(self):
        with TemporaryDirectory() as temp:
            cache = ResponseCache(Path(temp))
            calls = 0

            def transport(request, timeout):
                nonlocal calls
                calls += 1
                return FakeResponse(atom_feed([("2204.05381v4", "Paper", "Abstract")]))

            first = ArxivOfficialAdapter(
                cache=cache,
                transport=transport,
                request_interval_seconds=0,
            )
            first.lookup_by_ids(["2204.05381"])
            second = ArxivOfficialAdapter(
                cache=cache,
                transport=transport,
                request_interval_seconds=0,
            )
            result = second.lookup_by_ids(["2204.05381"])
            self.assertEqual(calls, 1)
            self.assertEqual(result.cached_pages, 1)

    def test_http_400_is_not_retried(self):
        calls = 0

        def transport(request, timeout):
            nonlocal calls
            calls += 1
            raise urllib.error.HTTPError(
                request.full_url,
                400,
                "Bad Request",
                {},
                None,
            )

        adapter = ArxivOfficialAdapter(
            transport=transport,
            request_interval_seconds=0,
            retries=3,
        )
        with self.assertRaises(ArxivQueryError):
            adapter.search(
                make_topic(),
                DateWindow.from_values(days=7, today=date(2026, 6, 25)),
                10,
                10,
                1,
            )
        self.assertEqual(calls, 1)

    def test_http_429_is_retried(self):
        calls = 0
        sleeps: list[float] = []

        def transport(request, timeout):
            nonlocal calls
            calls += 1
            if calls == 1:
                raise urllib.error.HTTPError(
                    request.full_url,
                    429,
                    "Too Many Requests",
                    {"Retry-After": "1"},
                    None,
                )
            return FakeResponse(atom_feed([], total=0))

        adapter = ArxivOfficialAdapter(
            transport=transport,
            request_interval_seconds=0,
            retries=2,
            sleep=sleeps.append,
        )
        adapter.search(
            make_topic(),
            DateWindow.from_values(days=7, today=date(2026, 6, 25)),
            10,
            10,
            1,
        )
        self.assertEqual(calls, 2)
        self.assertEqual(sleeps, [1.0])

    def test_timeout_is_retried_then_reported(self):
        calls = 0

        def transport(request, timeout):
            nonlocal calls
            calls += 1
            raise TimeoutError("simulated timeout")

        adapter = ArxivOfficialAdapter(
            transport=transport,
            request_interval_seconds=0,
            retries=2,
            sleep=lambda seconds: None,
        )
        with self.assertRaises(ArxivApiError):
            adapter.search(
                make_topic(),
                DateWindow.from_values(days=7, today=date(2026, 6, 25)),
                10,
                10,
                1,
            )
        self.assertEqual(calls, 2)


class HistoryAndPipelineTests(unittest.TestCase):
    def test_history_distinguishes_seen_and_updated(self):
        with TemporaryDirectory() as temp:
            path = Path(temp) / "history.json"
            store = HistoryStore(path)
            store.mark("fusion", "2606.00001v1", "2026-06-21T00:00:00Z")
            self.assertEqual(store.status("fusion", "2606.00001v1"), "seen")
            self.assertEqual(store.status("fusion", "2606.00001v2"), "updated")
            self.assertEqual(store.status("fusion", "2606.00002v1"), "new")
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertIn("2606.00001", data["papers"])

    def test_history_can_clear_selected_or_all_entries(self):
        with TemporaryDirectory() as temp:
            path = Path(temp) / "history.json"
            store = HistoryStore(path)
            store.mark("fusion", "2606.00001v1")
            store.mark("fusion", "2606.00002v1")
            self.assertEqual(store.clear(["2606.00001v3"]), 1)
            self.assertEqual(store.status("fusion", "2606.00001v1"), "new")
            self.assertEqual(store.clear(), 1)
            self.assertEqual(store.status("fusion", "2606.00002v1"), "new")

    def test_pipeline_continues_after_one_topic_fails(self):
        class PartialAdapter:
            source_name = "fake"

            def search(self, topic, window, page_size, max_results, max_pages):
                if topic.id == "bad":
                    raise TimeoutError("simulated timeout")
                return AdapterSearchResult(
                    items=[make_paper()],
                    query=topic.query,
                    total_results=5,
                    pages_fetched=1,
                    network_pages=1,
                    cached_pages=0,
                    truncated=True,
                )

        good = make_topic()
        bad = make_topic()
        bad.id = "bad"
        bad.name = "失败方向"
        payload = BriefPipeline(PartialAdapter()).run(
            [good, bad],
            DateWindow.from_values(days=7, today=date(2026, 6, 25)),
            candidate_limit=3,
            papers_per_topic=2,
        )
        self.assertEqual(payload["summary"]["failed_topic_count"], 1)
        self.assertTrue(payload["summary"]["any_truncated"])
        self.assertIsNone(payload["topics"][0]["error"])
        self.assertIn("TimeoutError", payload["topics"][1]["error"])
        self.assertTrue(payload["metadata_only"])
        self.assertFalse(payload["pdf_or_full_text_read"])

    def test_history_filter_backfills_to_candidate_limit(self):
        class ManyAdapter:
            source_name = "fake"

            def search(self, topic, window, page_size, max_results, max_pages):
                return AdapterSearchResult(
                    items=[
                        make_paper(f"2606.0000{index}v1")
                        for index in range(1, 5)
                    ],
                    query=topic.query,
                    total_results=4,
                    pages_fetched=1,
                    network_pages=1,
                    cached_pages=0,
                    truncated=False,
                )

        with TemporaryDirectory() as temp:
            history = HistoryStore(Path(temp) / "history.json")
            history.mark("uncertainty", "2606.00001v1")
            payload = BriefPipeline(ManyAdapter(), history=history).run(
                [make_topic()],
                DateWindow.from_values(days=7, today=date(2026, 6, 25)),
                candidate_limit=3,
                papers_per_topic=2,
            )
        candidates = payload["topics"][0]["candidates"]
        self.assertEqual(len(candidates), 3)
        self.assertNotIn(
            "2606.00001v1",
            [item["paper"]["source_id"] for item in candidates],
        )

    def test_updated_version_is_separated_from_new_candidates(self):
        class UpdatedAdapter:
            source_name = "fake"

            def search(self, topic, window, page_size, max_results, max_pages):
                return AdapterSearchResult(
                    items=[make_paper("2606.00001v2")],
                    query=topic.query,
                    total_results=1,
                    pages_fetched=1,
                    network_pages=1,
                    cached_pages=0,
                    truncated=False,
                )

        with TemporaryDirectory() as temp:
            history = HistoryStore(Path(temp) / "history.json")
            history.mark("uncertainty", "2606.00001v1")
            payload = BriefPipeline(UpdatedAdapter(), history=history).run(
                [make_topic()],
                DateWindow.from_values(days=7, today=date(2026, 6, 25)),
                candidate_limit=3,
                papers_per_topic=1,
            )
        topic = payload["topics"][0]
        self.assertEqual(topic["candidates"], [])
        self.assertEqual(len(topic["important_updates"]), 1)
        self.assertEqual(
            topic["important_updates"][0]["history_status"],
            "updated",
        )

    def test_empty_results_remain_empty(self):
        class EmptyAdapter:
            source_name = "fake"

            def search(self, topic, window, page_size, max_results, max_pages):
                return AdapterSearchResult(
                    items=[],
                    query=topic.query,
                    total_results=0,
                    pages_fetched=1,
                    network_pages=1,
                    cached_pages=0,
                    truncated=False,
                )

        payload = BriefPipeline(EmptyAdapter()).run(
            [make_topic()],
            DateWindow.from_values(days=7, today=date(2026, 6, 25)),
            candidate_limit=3,
            papers_per_topic=1,
        )
        self.assertEqual(payload["topics"][0]["candidates"], [])
        self.assertEqual(payload["topics"][0]["stats"]["candidate_count"], 0)


class ProfileAndReportTests(unittest.TestCase):
    def test_skill_files_have_no_local_paths_or_placeholders(self):
        forbidden = (
            r"C:" + r"\Users",
            r"D:" + r"\Desktop",
            r"E:" + r"\Anaconda3",
            "[TO" + "DO:",
            "editorial" + "_notes",
            '"priority' + '_ids"',
        )
        text_files = [
            path
            for path in SKILL_ROOT.rglob("*")
            if path.is_file()
            and path.suffix.lower() in {".md", ".py", ".json", ".yaml", ".yml"}
            and "__pycache__" not in path.parts
        ]
        for path in text_files:
            text = path.read_text(encoding="utf-8")
            for marker in forbidden:
                self.assertNotIn(marker, text, f"{marker!r} found in {path}")

    def test_openai_metadata_mentions_exact_skill_name(self):
        text = (SKILL_ROOT / "agents" / "openai.yaml").read_text(encoding="utf-8")
        self.assertIn("$arxiv-research-brief", text)

    def test_builtin_profile_has_five_topics_without_fixed_paper_ids(self):
        topics = load_profile(profile="multimodal")
        self.assertEqual(len(topics), 5)
        self.assertEqual(
            [topic.name for topic in topics],
            [
                "多模态表征学习",
                "多模态融合策略",
                "不完整多模态学习",
                "不确定性感知多模态融合",
                "多模态蒸馏",
            ],
        )
        raw = json.loads(
            (SKILL_ROOT / "references" / "multimodal-profile.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertNotIn("priority" + "_ids", json.dumps(raw))

    def test_custom_topic_supports_keywords_and_filters(self):
        topic = build_custom_topic(
            topic_id="custom",
            name="Custom",
            query=None,
            keywords=["multimodal fusion"],
            required_groups=["multimodal|multi-modal", "fusion"],
            positive_terms=["multimodal fusion=8"],
            negative_terms=["survey=-4"],
            exclude_terms=["nuclear fusion"],
            categories=["cs.CV"],
            min_score=5,
        )
        self.assertIn('all:"multimodal fusion"', topic.query)
        self.assertEqual(topic.categories, ["cs.CV"])
        self.assertEqual(topic.min_score, 5)

    def test_raw_query_without_scoring_terms_returns_rankable_results(self):
        topic = build_custom_topic(
            topic_id="raw",
            name="Raw query",
            query="au:Vaswani",
            keywords=[],
            required_groups=[],
            positive_terms=[],
            negative_terms=[],
            exclude_terms=[],
            categories=[],
            min_score=None,
        )
        ranked = rank_papers([make_paper()], topic, candidate_limit=3)
        self.assertEqual(len(ranked), 1)
        self.assertEqual(ranked[0].relevance_score, 0)

    def test_lookup_cli_outputs_specified_papers_payload(self):
        class FakeLookupAdapter:
            source_name = "arXiv official Atom API"

            def __init__(self, cache=None):
                self.cache = cache

            def lookup_by_ids(self, ids):
                return AdapterSearchResult(
                    items=[
                        make_paper("2204.05381v4"),
                        make_paper("2204.01678v1"),
                    ],
                    query="id_list:" + ",".join(ids),
                    total_results=2,
                    pages_fetched=1,
                    network_pages=1,
                    cached_pages=0,
                    truncated=False,
                )

        original = cli_module.ArxivOfficialAdapter
        cli_module.ArxivOfficialAdapter = FakeLookupAdapter
        try:
            output = io.StringIO()
            with redirect_stdout(output):
                exit_code = main(
                    [
                        "lookup",
                        "https://arxiv.org/abs/2204.05381",
                        "not-an-arxiv-id",
                        "2309.05300v3",
                        "2204.01678",
                        "--no-cache",
                    ]
                )
        finally:
            cli_module.ArxivOfficialAdapter = original
        self.assertEqual(exit_code, 0)
        payload = json.loads(output.getvalue())
        topic = payload["topics"][0]
        self.assertEqual(topic["id"], "specified-papers")
        self.assertEqual(topic["name"], "指定 arXiv 论文")
        self.assertEqual(
            [item["paper"]["source_id"] for item in topic["candidates"]],
            ["2204.05381v4", "2204.01678v1"],
        )
        self.assertEqual(
            topic["candidates"][0]["relevance_reasons"],
            ["user-specified arXiv ID"],
        )
        self.assertIn("not-an-arxiv-id", [item["input"] for item in payload["missing_inputs"]])
        self.assertIn("2309.05300v3", [item["input"] for item in payload["missing_inputs"]])

    def test_report_validator_accepts_complete_cards(self):
        text = """\
# arXiv 研究简报

## 检索范围与统计
内容
## 各方向速览
内容
## 重要更新
无
## 多模态融合策略
### 1. [Paper](https://arxiv.org/abs/2606.00001)
- **元数据：** arXiv `2606.00001v1`；首次提交 2026-06-20。
- **刊会状态：** 未确认。
- **研究问题：** 问题。
- **核心方法：** 方法。
- **摘要证据：** 实验。
- **阅读建议：** 精读。
- **风险与局限：** 仅依据摘要。
## 跨方向趋势
证据不足。
## 判断边界
仅依据摘要。
"""
        self.assertEqual(validate_report(text, ["多模态融合策略"]), [])

    def test_report_validator_rejects_missing_fields(self):
        errors = validate_report(
            "## 检索范围与统计\n## 多模态融合策略\n### 1. Paper",
            ["多模态融合策略"],
        )
        self.assertTrue(any("Missing heading" in error for error in errors))
        self.assertTrue(any("missing **元数据：**" in error for error in errors))

    def test_validate_report_cli(self):
        with TemporaryDirectory() as temp:
            path = Path(temp) / "brief.md"
            path.write_text(
                """\
## 检索范围与统计
## 各方向速览
## 重要更新
## Topic
本期无达到相关性阈值的论文，未使用低相关结果凑数。
## 跨方向趋势
## 判断边界
""",
                encoding="utf-8",
            )
            output = io.StringIO()
            with redirect_stdout(output):
                exit_code = main(
                    [
                        "validate-report",
                        "--input",
                        str(path),
                        "--topic",
                        "Topic",
                    ]
                )
            self.assertEqual(exit_code, 0)
            self.assertTrue(json.loads(output.getvalue())["valid"])


if __name__ == "__main__":
    unittest.main()
