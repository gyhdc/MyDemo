# Custom profile schema

Use a JSON object with a non-empty `topics` array. Each topic is searched independently and becomes one report section.

```json
{
  "topics": [
    {
      "id": "robust-fusion",
      "name": "鲁棒多模态融合",
      "query": "(all:multimodal AND all:fusion AND all:robustness)",
      "required_groups": [
        ["multimodal", "multi-modal"],
        ["fusion", "integration"],
        ["robust", "robustness"]
      ],
      "positive_terms": {
        "robust multimodal fusion": 12,
        "modality corruption": 8
      },
      "negative_terms": {
        "survey": -4
      },
      "exclude_terms": [
        "nuclear fusion"
      ],
      "categories": [
        "cs.CV",
        "cs.LG"
      ],
      "min_score": 7
    }
  ]
}
```

Field rules:

- `id`, `name`, and `query` are required.
- Every group in `required_groups` is mandatory; one alternative within each group must occur in the title or abstract.
- `positive_terms` contributes only to relevance. A title match receives a larger weight than an abstract-only match.
- `negative_terms` reduces relevance but does not automatically reject a paper.
- `exclude_terms` rejects a paper when any term occurs.
- `categories` is optional. When set, it becomes a server-side arXiv category restriction.
- `min_score` controls low-match rejection. Prefer a smaller result set over filling the report with weak matches.

Use raw arXiv query syntax only in `query`. The script adds the exact `submittedDate` clause.
