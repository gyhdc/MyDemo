# Research brief format

Produce the complete report in the chat. A temporary file may be used only for validation.

```markdown
# arXiv 研究简报：<主题、预设名称或指定论文>

> 时间范围：<START> 至 <END>；生成日期：<DATE>；数据源：arXiv official Atom API。
> 判断范围：仅基于题名、摘要与元数据，未读取 PDF 或全文。

## 检索范围与统计

- 方向：...
- API 原始命中：...
- 候选摘要数：...
- 截断或失败：...

直接查询指定 arXiv 论文时：

- 时间范围写“不适用（指定论文查询）”。
- 方向默认写“指定 arXiv 论文”；若用户给出主题名，使用用户主题名。
- API 原始命中写 arXiv 返回条目数。
- 候选摘要数写实际进入报告的论文数。
- 截断或失败写 API 错误、未识别输入、未返回输入；没有则写“无”。

## 各方向速览

| 方向 | 入选数 | 最值得关注 | 一句话判断 |
|---|---:|---|---|

## 重要更新

列出历史记录中版本发生变化的论文。没有则写“本期无已跟踪论文的重要版本更新”。

## <方向名称>

### 1. [<Title>](<ARXIV_ABSTRACT_URL>)

- **元数据：** arXiv `<ID>`；首次提交 `<DATE>`；最近更新 `<DATE>`；作者 `<AUTHORS>`；分类 `<CATEGORIES>`。
- **刊会状态：** `<仅使用 arXiv journal_ref/comment/DOI；如完成可靠补充查询，注明来源；否则写未确认>`。
- **研究问题：** `<根据摘要重述任务背景、应用场景、现有方法缺口或失败模式，不复制长段原文>`。
- **核心方法：** `<根据摘要说明核心 insight、主要创新点、方法流程、关键模块、训练/推理机制或融合/蒸馏/对齐策略；要解释作者观察到什么矛盾/瓶颈/被忽略信号，以及方法为什么从这个 insight 自然推出；不要只写模型名或“提出某方法”>`。
- **摘要证据：** `<写明摘要中出现的数据集、任务、实验、消融、指标、数值结果、理论分析、代码声明或应用验证；没有则明确写“摘要未给出具体数据集/指标/数值证据”>`。
- **阅读建议：** `<精读/选读/关注>`；`<说明适合哪类读者、为什么值得读、它对当前方向的具体参考价值；指出即使读者不熟悉该任务或算法，也能借鉴的建模想法、问题转化方式或验证思路>`。
- **风险与局限：** `<仅凭摘要无法确认的事项、任务范围、数据范围、评审状态、可复现性、跨任务泛化等；不要泛泛写“需要进一步验证”>`。

若没有论文达到阈值，写：

“本期无达到相关性阈值的论文，未使用低相关结果凑数。”

直接查询指定 arXiv 论文时，不使用相关性阈值；所有有效返回论文都写成论文卡片。若没有有效返回论文，写：

“本次指定的 arXiv 输入没有返回可汇报的论文，未编造论文信息。”

若所有方向均为零原始命中或零合格候选，停止生成论文卡片，并报告检索时间范围、使用的 query/profile、零命中或零候选状态；不要自动放宽条件重试。

若该方向检索失败，写：

“该方向检索失败：<ERROR>。其他方向结果不受影响。”

## 跨方向趋势

仅写至少由两篇入选论文共同支持的趋势。证据不足时写“本期候选不足以支持稳定的跨方向趋势判断”。

## 判断边界

- 本简报不等价于同行评审结论。
- 未声明刊会不代表未投稿或未录用。
- 阅读建议依据主题相关性、摘要所述贡献和证据完整度，不依据引用量。
```

Selection rules:

- Read every returned candidate title, full abstract, and metadata before selecting.
- Select at most the requested number per topic; fewer is valid.
- Keep `relevance_score`, evidence hints, and recency conceptually separate.
- Do not infer experiment quality beyond the abstract.
- Do not invent venue status or use ambiguous venue matches.
- Keep the exact card fields and order above; do not add new card fields or nested subsections.
- Direct lookup reports use the same headings and card fields; only the title, time-range wording, topic name, and statistics adapt to specified-paper lookup.
- For each selected paper, the combined `研究问题` + `核心方法` + `摘要证据` content should normally be 5-8 Chinese sentences unless the abstract itself is unusually short.
- `研究问题` should answer: what task/scenario is this about, and what gap motivates the work?
- `核心方法` should answer: what are the main steps/modules, what is the key insight, how might the authors have arrived at the method from the task difficulty, and how does the method solve the stated gap?
- `摘要证据` should answer: what did the authors claim to test or validate, on what data/task, and with what kind of result?
- `阅读建议` should include the transferable idea: what a reader can learn from the work even if the exact task, dataset, or model family is outside their own area.
- Every selected-paper card should contain one concise insight judgment, usually inside `核心方法` or `阅读建议`: "the authors turn <task difficulty> into <method idea>". This sentence is the guardrail against abstract paraphrase and professional-term stacking.
- Avoid thin summaries such as “本文提出 X，用于 Y，并在 Z 上验证有效”. This is not enough for a research brief when the abstract contains more usable detail.
- Avoid professional-term stacking. When mentioning a named mechanism, also explain its role in plain research logic, such as “it filters noisy trajectories”, “it turns missing labels into a contrastive signal”, or “it makes uncertainty decide when to defer”.
