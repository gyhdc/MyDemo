from arxiv_research_brief.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
