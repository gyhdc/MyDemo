from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Any


VERSION_RE = re.compile(r"v(\d+)$", re.IGNORECASE)


@dataclass
class PaperRecord:
    source: str
    source_id: str
    title: str
    abstract: str
    authors: list[str]
    affiliations: list[str]
    published: str
    updated: str
    primary_category: str
    categories: list[str]
    abstract_url: str
    pdf_url: str
    comment: str = ""
    journal_ref: str = ""
    doi: str = ""

    @property
    def canonical_id(self) -> str:
        return VERSION_RE.sub("", self.source_id)

    @property
    def version(self) -> int:
        match = VERSION_RE.search(self.source_id)
        return int(match.group(1)) if match else 1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "PaperRecord":
        return cls(**value)


@dataclass
class SearchPage:
    items: list[PaperRecord]
    total_results: int
    start_index: int
    items_per_page: int


@dataclass
class AdapterSearchResult:
    items: list[PaperRecord]
    query: str
    total_results: int
    pages_fetched: int
    network_pages: int
    cached_pages: int
    truncated: bool


@dataclass
class TopicSpec:
    id: str
    name: str
    query: str
    required_groups: list[list[str]] = field(default_factory=list)
    positive_terms: dict[str, float] = field(default_factory=dict)
    negative_terms: dict[str, float] = field(default_factory=dict)
    exclude_terms: list[str] = field(default_factory=list)
    categories: list[str] = field(default_factory=list)
    min_score: float = 1.0

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "TopicSpec":
        required = {"id", "name", "query"}
        missing = sorted(required - value.keys())
        if missing:
            raise ValueError(f"Topic is missing required fields: {', '.join(missing)}")
        topic = cls(
            id=str(value["id"]).strip(),
            name=str(value["name"]).strip(),
            query=str(value["query"]).strip(),
            required_groups=[
                [str(term).strip() for term in group if str(term).strip()]
                for group in value.get("required_groups", [])
            ],
            positive_terms={
                str(term): float(weight)
                for term, weight in value.get("positive_terms", {}).items()
            },
            negative_terms={
                str(term): float(weight)
                for term, weight in value.get("negative_terms", {}).items()
            },
            exclude_terms=[
                str(term).strip()
                for term in value.get("exclude_terms", [])
                if str(term).strip()
            ],
            categories=[
                str(category).strip()
                for category in value.get("categories", [])
                if str(category).strip()
            ],
            min_score=float(value.get("min_score", 1.0)),
        )
        if not topic.id or not topic.name or not topic.query:
            raise ValueError("Topic id, name, and query must be non-empty")
        if any(not group for group in topic.required_groups):
            raise ValueError(f"Topic {topic.id!r} contains an empty required group")
        return topic

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RankedPaper:
    paper: PaperRecord
    topic_id: str
    topic_name: str
    relevance_score: float
    relevance_reasons: list[str]
    evidence_hint: list[str]
    history_status: str = "new"

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["paper"] = self.paper.to_dict()
        return value
