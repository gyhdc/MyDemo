from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import PaperRecord, RankedPaper


class HistoryStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.data = self._load()

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"schema_version": 1, "papers": {}}
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"Invalid history file: {self.path}") from exc
        if not isinstance(value, dict) or not isinstance(value.get("papers"), dict):
            raise ValueError(f"Invalid history schema: {self.path}")
        value.setdefault("schema_version", 1)
        return value

    def status(self, topic_id: str, source_id: str) -> str:
        paper = PaperRecord(
            source="arxiv",
            source_id=source_id,
            title="",
            abstract="",
            authors=[],
            affiliations=[],
            published="",
            updated="",
            primary_category="",
            categories=[],
            abstract_url="",
            pdf_url="",
        )
        record = self.data["papers"].get(paper.canonical_id)
        if record is None:
            return "new"
        if paper.version > int(record.get("latest_version", 1)):
            return "updated"
        return "seen"

    def mark(
        self,
        topic_id: str,
        source_id: str,
        recommended_at: str | None = None,
    ) -> None:
        paper = PaperRecord(
            source="arxiv",
            source_id=source_id,
            title="",
            abstract="",
            authors=[],
            affiliations=[],
            published="",
            updated="",
            primary_category="",
            categories=[],
            abstract_url="",
            pdf_url="",
        )
        timestamp = recommended_at or datetime.now(timezone.utc).isoformat()
        record = self.data["papers"].setdefault(
            paper.canonical_id,
            {
                "source": "arxiv",
                "source_id": source_id,
                "latest_version": paper.version,
                "first_recommended_at": timestamp,
                "last_recommended_at": timestamp,
                "topics": [],
            },
        )
        record["source_id"] = source_id
        record["latest_version"] = max(
            int(record.get("latest_version", 1)),
            paper.version,
        )
        record["last_recommended_at"] = timestamp
        topics = record.setdefault("topics", [])
        if topic_id not in topics:
            topics.append(topic_id)
            topics.sort()
        self.save()

    def annotate(
        self,
        items: list[RankedPaper],
        include_seen: bool = False,
    ) -> list[RankedPaper]:
        visible: list[RankedPaper] = []
        for item in items:
            item.history_status = self.status(item.topic_id, item.paper.source_id)
            if include_seen or item.history_status != "seen":
                visible.append(item)
        return visible

    def clear(self, source_ids: list[str] | None = None) -> int:
        papers = self.data["papers"]
        if source_ids is None:
            removed = len(papers)
            papers.clear()
        else:
            canonical_ids = {
                PaperRecord(
                    source="arxiv",
                    source_id=source_id,
                    title="",
                    abstract="",
                    authors=[],
                    affiliations=[],
                    published="",
                    updated="",
                    primary_category="",
                    categories=[],
                    abstract_url="",
                    pdf_url="",
                ).canonical_id
                for source_id in source_ids
            }
            removed = 0
            for canonical_id in canonical_ids:
                if canonical_id in papers:
                    del papers[canonical_id]
                    removed += 1
        self.save()
        return removed

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(self.data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
