from __future__ import annotations

import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
from typing import Callable

from .cache import ResponseCache
from .models import AdapterSearchResult, TopicSpec
from .query import DateWindow, build_search_query
from .xml_parser import parse_atom_feed


class ArxivApiError(RuntimeError):
    pass


class ArxivQueryError(ArxivApiError):
    pass


class SearchAdapter(ABC):
    source_name: str

    @abstractmethod
    def search(
        self,
        topic: TopicSpec,
        window: DateWindow,
        page_size: int,
        max_results: int,
        max_pages: int,
    ) -> AdapterSearchResult:
        raise NotImplementedError


class ArxivOfficialAdapter(SearchAdapter):
    source_name = "arXiv official Atom API"
    endpoint = "https://export.arxiv.org/api/query"

    def __init__(
        self,
        cache: ResponseCache | None = None,
        user_agent: str = "CodexArxivResearchBrief/1.0 (metadata-only monitoring)",
        request_interval_seconds: float = 3.1,
        timeout_seconds: int = 90,
        retries: int = 3,
        transport: Callable | None = None,
        sleep: Callable[[float], None] = time.sleep,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self.cache = cache
        self.user_agent = user_agent
        self.request_interval_seconds = request_interval_seconds
        self.timeout_seconds = timeout_seconds
        self.retries = max(1, retries)
        self.transport = transport or urllib.request.urlopen
        self.sleep = sleep
        self.monotonic = monotonic
        self._last_request_at: float | None = None

    def search(
        self,
        topic: TopicSpec,
        window: DateWindow,
        page_size: int = 100,
        max_results: int = 300,
        max_pages: int = 5,
    ) -> AdapterSearchResult:
        if not 1 <= page_size <= 2000:
            raise ValueError("page_size must be between 1 and 2000")
        if max_results < 1 or max_pages < 1:
            raise ValueError("max_results and max_pages must be at least 1")
        query = build_search_query(topic.query, window, topic.categories)
        items = []
        total_results = 0
        start = 0
        pages_fetched = 0
        network_pages = 0
        cached_pages = 0

        while pages_fetched < max_pages and len(items) < max_results:
            requested = min(page_size, max_results - len(items))
            payload, from_cache = self._fetch_page(query, start, requested)
            if from_cache:
                cached_pages += 1
            else:
                network_pages += 1
            try:
                root = ET.fromstring(payload)
            except ET.ParseError as exc:
                raise ArxivApiError("arXiv returned invalid XML") from exc
            page = parse_atom_feed(root)
            error_entry = root.find("{http://www.w3.org/2005/Atom}entry")
            if (
                not page.items
                and error_entry is not None
                and "/api/errors" in (
                    error_entry.findtext("{http://www.w3.org/2005/Atom}id") or ""
                )
            ):
                message = error_entry.findtext("{http://www.w3.org/2005/Atom}summary")
                raise ArxivQueryError(message or "arXiv rejected the query")
            pages_fetched += 1
            total_results = page.total_results
            items.extend(page.items)
            if not page.items:
                break
            consumed = page.items_per_page or len(page.items)
            start = page.start_index + consumed
            if start >= total_results:
                break

        return AdapterSearchResult(
            items=items[:max_results],
            query=query,
            total_results=total_results,
            pages_fetched=pages_fetched,
            network_pages=network_pages,
            cached_pages=cached_pages,
            truncated=total_results > min(len(items), max_results),
        )

    def lookup_by_ids(self, ids: list[str]) -> AdapterSearchResult:
        cleaned_ids = [item.strip() for item in ids if item.strip()]
        if not cleaned_ids:
            raise ValueError("Provide at least one arXiv ID")
        payload, from_cache = self._fetch_id_list(cleaned_ids)
        try:
            root = ET.fromstring(payload)
        except ET.ParseError as exc:
            raise ArxivApiError("arXiv returned invalid XML") from exc
        page = parse_atom_feed(root)
        error_entry = root.find("{http://www.w3.org/2005/Atom}entry")
        if (
            not page.items
            and error_entry is not None
            and "/api/errors" in (
                error_entry.findtext("{http://www.w3.org/2005/Atom}id") or ""
            )
        ):
            message = error_entry.findtext("{http://www.w3.org/2005/Atom}summary")
            raise ArxivQueryError(message or "arXiv rejected the id_list query")
        return AdapterSearchResult(
            items=page.items,
            query=f"id_list:{','.join(cleaned_ids)}",
            total_results=page.total_results,
            pages_fetched=1,
            network_pages=0 if from_cache else 1,
            cached_pages=1 if from_cache else 0,
            truncated=False,
        )

    def _fetch_page(
        self,
        query: str,
        start: int,
        max_results: int,
    ) -> tuple[bytes, bool]:
        params = urllib.parse.urlencode(
            {
                "search_query": query,
                "start": start,
                "max_results": max_results,
                "sortBy": "submittedDate",
                "sortOrder": "descending",
            }
        )
        url = f"{self.endpoint}?{params}"
        return self._fetch_url(url)

    def _fetch_id_list(self, ids: list[str]) -> tuple[bytes, bool]:
        params = urllib.parse.urlencode({"id_list": ",".join(ids)})
        url = f"{self.endpoint}?{params}"
        return self._fetch_url(url)

    def _fetch_url(self, url: str) -> tuple[bytes, bool]:
        if self.cache:
            cached = self.cache.get(url)
            if cached is not None:
                return cached, True

        request = urllib.request.Request(url, headers={"User-Agent": self.user_agent})
        last_error: Exception | None = None
        for attempt in range(self.retries):
            self._respect_rate_limit()
            try:
                self._last_request_at = self.monotonic()
                with self.transport(request, timeout=self.timeout_seconds) as response:
                    payload = response.read()
                if self.cache:
                    self.cache.set(url, payload)
                return payload, False
            except urllib.error.HTTPError as exc:
                last_error = exc
                if exc.code != 429 and 400 <= exc.code < 500:
                    raise ArxivQueryError(
                        f"arXiv rejected the query with HTTP {exc.code}"
                    ) from exc
                if exc.code != 429 and exc.code < 500:
                    raise
                retry_after = exc.headers.get("Retry-After") if exc.headers else None
                delay = float(retry_after) if retry_after else 3.0 * (attempt + 1)
            except (TimeoutError, urllib.error.URLError, ConnectionError) as exc:
                last_error = exc
                delay = 3.0 * (attempt + 1)
            if attempt + 1 < self.retries:
                self.sleep(delay)
        raise ArxivApiError(f"arXiv request failed after {self.retries} attempts") from last_error

    def _respect_rate_limit(self) -> None:
        if self._last_request_at is None:
            return
        elapsed = self.monotonic() - self._last_request_at
        remaining = self.request_interval_seconds - elapsed
        if remaining > 0:
            self.sleep(remaining)
