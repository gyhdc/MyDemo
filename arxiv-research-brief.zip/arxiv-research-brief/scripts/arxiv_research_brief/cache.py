from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path


class ResponseCache:
    def __init__(self, root: Path, ttl_seconds: int = 86400) -> None:
        self.root = root
        self.ttl_seconds = ttl_seconds
        self.root.mkdir(parents=True, exist_ok=True)

    def _paths(self, key: str) -> tuple[Path, Path]:
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return self.root / f"{digest}.bin", self.root / f"{digest}.json"

    def get(self, key: str, now: float | None = None) -> bytes | None:
        data_path, meta_path = self._paths(key)
        if not data_path.exists() or not meta_path.exists():
            return None
        try:
            metadata = json.loads(meta_path.read_text(encoding="utf-8"))
            created_at = float(metadata["created_at"])
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            self._delete_pair(data_path, meta_path)
            return None
        current = time.time() if now is None else now
        if current - created_at > self.ttl_seconds:
            self._delete_pair(data_path, meta_path)
            return None
        try:
            return data_path.read_bytes()
        except OSError:
            self._delete_pair(data_path, meta_path)
            return None

    def set(self, key: str, value: bytes, now: float | None = None) -> None:
        data_path, meta_path = self._paths(key)
        created_at = time.time() if now is None else now
        data_path.write_bytes(value)
        meta_path.write_text(
            json.dumps({"key": key, "created_at": created_at}, ensure_ascii=False),
            encoding="utf-8",
        )

    def cleanup(self, now: float | None = None) -> int:
        current = time.time() if now is None else now
        removed = 0
        for meta_path in self.root.glob("*.json"):
            data_path = meta_path.with_suffix(".bin")
            try:
                metadata = json.loads(meta_path.read_text(encoding="utf-8"))
                expired = current - float(metadata["created_at"]) > self.ttl_seconds
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                expired = True
            if expired or not data_path.exists():
                self._delete_pair(data_path, meta_path)
                removed += 1
        for data_path in self.root.glob("*.bin"):
            if not data_path.with_suffix(".json").exists():
                data_path.unlink(missing_ok=True)
                removed += 1
        return removed

    @staticmethod
    def _delete_pair(data_path: Path, meta_path: Path) -> None:
        data_path.unlink(missing_ok=True)
        meta_path.unlink(missing_ok=True)
