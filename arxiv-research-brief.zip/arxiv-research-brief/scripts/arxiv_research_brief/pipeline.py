from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .adapters import SearchAdapter
from .history import HistoryStore
from .models import PaperRecord, TopicSpec
from .query import DateWindow
from .ranking import rank_papers


def deduplicate_versions(papers: list[PaperRecord]) -> list[PaperRecord]:
    unique: dict[str, PaperRecord] = {}
    for paper in papers:
        existing = unique.get(paper.canonical_id)
        if existing is None or (
            paper.version,
            paper.updated,
        ) > (
            existing.version,
            existing.updated,
        ):
            unique[paper.canonical_id] = paper
    return list(unique.values())


class BriefPipeline:
    def __init__(
        self,
        adapter: SearchAdapter,
        history: HistoryStore | None = None,
    ) -> None:
        self.adapter = adapter
        self.history = history

    def run(
        self,
        topics: list[TopicSpec],
        window: DateWindow,
        candidate_limit: int = 8,
        papers_per_topic: int = 3,
        page_size: int = 100,
        max_results_per_topic: int = 300,
        max_pages: int = 5,
        include_seen: bool = False,
    ) -> dict[str, Any]:
        if not 1 <= papers_per_topic <= 10:
            raise ValueError("papers_per_topic must be between 1 and 10")
        if candidate_limit < papers_per_topic:
            raise ValueError("candidate_limit must be at least papers_per_topic")
        topic_payloads: list[dict[str, Any]] = []
        raw_count = 0
        unique_ids: set[str] = set()
        errors = 0
        any_truncated = False

        for topic in topics:
            try:
                result = self.adapter.search(
                    topic=topic,
                    window=window,
                    page_size=page_size,
                    max_results=max_results_per_topic,
                    max_pages=max_pages,
                )
                unique = deduplicate_versions(result.items)
                raw_count += len(result.items)
                unique_ids.update(paper.canonical_id for paper in unique)
                ranked = rank_papers(
                    unique,
                    topic,
                    candidate_limit=max(1, len(unique)),
                )
                eligible_before_history = len(ranked)
                if self.history:
                    ranked = self.history.annotate(ranked, include_seen=include_seen)
                visible = ranked[:candidate_limit]
                candidates = [
                    item.to_dict()
                    for item in visible
                    if item.history_status != "updated"
                ]
                updates = [
                    item.to_dict()
                    for item in visible
                    if item.history_status == "updated"
                ]
                any_truncated = any_truncated or result.truncated
                topic_payloads.append(
                    {
                        "id": topic.id,
                        "name": topic.name,
                        "query": result.query,
                        "requested_papers": papers_per_topic,
                        "candidates": candidates,
                        "important_updates": updates,
                        "stats": {
                            "api_total_results": result.total_results,
                            "fetched": len(result.items),
                            "unique": len(unique),
                            "eligible_before_history": eligible_before_history,
                            "candidate_count": len(candidates),
                            "update_count": len(updates),
                            "pages_fetched": result.pages_fetched,
                            "network_pages": result.network_pages,
                            "cached_pages": result.cached_pages,
                            "truncated": result.truncated,
                        },
                        "error": None,
                    }
                )
            except Exception as exc:
                errors += 1
                topic_payloads.append(
                    {
                        "id": topic.id,
                        "name": topic.name,
                        "query": topic.query,
                        "requested_papers": papers_per_topic,
                        "candidates": [],
                        "important_updates": [],
                        "stats": {
                            "api_total_results": 0,
                            "fetched": 0,
                            "unique": 0,
                            "eligible_before_history": 0,
                            "candidate_count": 0,
                            "update_count": 0,
                            "pages_fetched": 0,
                            "network_pages": 0,
                            "cached_pages": 0,
                            "truncated": False,
                        },
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

        return {
            "schema_version": 1,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "source": self.adapter.source_name,
            "metadata_only": True,
            "pdf_or_full_text_read": False,
            "date_window": window.to_dict(),
            "candidate_limit_per_topic": candidate_limit,
            "requested_papers_per_topic": papers_per_topic,
            "summary": {
                "topic_count": len(topics),
                "failed_topic_count": errors,
                "raw_fetched": raw_count,
                "unique_across_topics": len(unique_ids),
                "any_truncated": any_truncated,
            },
            "topics": topic_payloads,
        }
