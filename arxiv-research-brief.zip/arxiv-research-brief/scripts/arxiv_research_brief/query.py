from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta


@dataclass(frozen=True)
class DateWindow:
    start: date
    end: date

    @classmethod
    def from_values(
        cls,
        days: int | None = None,
        start: str | None = None,
        end: str | None = None,
        today: date | None = None,
    ) -> "DateWindow":
        today = today or date.today()
        if days is not None and (start or end):
            raise ValueError("--days cannot be combined with --start or --end")
        if days is not None:
            if days < 1:
                raise ValueError("--days must be at least 1")
            return cls(start=today - timedelta(days=days - 1), end=today)
        if start or end:
            if not start or not end:
                raise ValueError("--start and --end must be provided together")
            start_date = date.fromisoformat(start)
            end_date = date.fromisoformat(end)
            if start_date > end_date:
                raise ValueError("--start must not be later than --end")
            return cls(start=start_date, end=end_date)
        return cls(start=today - timedelta(days=6), end=today)

    @property
    def days(self) -> int:
        return (self.end - self.start).days + 1

    def arxiv_bounds(self) -> tuple[str, str]:
        return (
            self.start.strftime("%Y%m%d") + "0000",
            self.end.strftime("%Y%m%d") + "2359",
        )

    def to_dict(self) -> dict[str, str | int]:
        return {
            "start": self.start.isoformat(),
            "end": self.end.isoformat(),
            "days": self.days,
        }


def build_search_query(
    base_query: str,
    window: DateWindow,
    categories: list[str] | None = None,
) -> str:
    query = base_query.strip()
    if not query:
        raise ValueError("arXiv query must not be empty")
    start, end = window.arxiv_bounds()
    parts = [f"({query})", f"submittedDate:[{start} TO {end}]"]
    category_values = [item.strip() for item in (categories or []) if item.strip()]
    if category_values:
        category_query = " OR ".join(f"cat:{item}" for item in category_values)
        parts.append(f"({category_query})")
    return " AND ".join(parts)


def term_to_query(term: str) -> str:
    value = term.strip()
    if not value:
        raise ValueError("Keyword must not be empty")
    escaped = value.replace('"', r"\"")
    return f'all:"{escaped}"' if any(char.isspace() for char in value) else f"all:{escaped}"


def keywords_to_query(keywords: list[str]) -> str:
    values = [term_to_query(term) for term in keywords if term.strip()]
    if not values:
        raise ValueError("At least one query or keyword is required")
    return " OR ".join(values)
