from __future__ import annotations

import argparse
import io
import json
import re
import sys
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .adapters import ArxivOfficialAdapter
from .cache import ResponseCache
from .history import HistoryStore
from .pipeline import BriefPipeline
from .profiles import BUILTIN_PROFILES, build_custom_topic, load_profile
from .query import DateWindow
from .report_validation import validate_report


ARXIV_ID_RE = re.compile(
    r"(?:[a-z-]+(?:\.[A-Z]{2})?/\d{7}|\d{4}\.\d{4,5})(?:v\d+)?",
    re.IGNORECASE,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Retrieve and pre-screen recent arXiv metadata and abstracts."
    )
    parser.add_argument("--version", action="version", version="1.0.0")
    subparsers = parser.add_subparsers(dest="command", required=True)

    search = subparsers.add_parser("search", help="Search and rank paper candidates")
    search.add_argument("--profile", choices=sorted(BUILTIN_PROFILES))
    search.add_argument("--profile-file", type=Path)
    search.add_argument("--topic-id", default="custom-topic")
    search.add_argument("--name", default="Custom topic")
    search.add_argument("--query", help="Raw arXiv search expression")
    search.add_argument("--keyword", action="append", default=[])
    search.add_argument(
        "--required-group",
        action="append",
        default=[],
        metavar="TERM|ALTERNATIVE",
    )
    search.add_argument("--positive", action="append", default=[], metavar="TERM=WEIGHT")
    search.add_argument("--negative", action="append", default=[], metavar="TERM=WEIGHT")
    search.add_argument("--exclude", action="append", default=[])
    search.add_argument("--category", action="append", default=[])
    search.add_argument("--min-score", type=float)
    search.add_argument("--days", type=int)
    search.add_argument("--start")
    search.add_argument("--end")
    search.add_argument("--candidate-limit", type=int, default=8)
    search.add_argument("--papers-per-topic", type=int, default=3)
    search.add_argument("--page-size", type=int, default=100)
    search.add_argument("--max-results-per-topic", type=int, default=300)
    search.add_argument("--max-pages", type=int, default=5)
    search.add_argument("--cache-dir", type=Path)
    search.add_argument("--cache-ttl-hours", type=float, default=24.0)
    search.add_argument("--no-cache", action="store_true")
    search.add_argument("--history-file", type=Path)
    search.add_argument("--include-seen", action="store_true")
    search.add_argument("--output", type=Path)
    search.set_defaults(handler=handle_search)

    lookup = subparsers.add_parser("lookup", help="Lookup specific arXiv IDs or URLs")
    lookup.add_argument("items", nargs="+", metavar="ARXIV_ID_OR_URL")
    lookup.add_argument("--cache-dir", type=Path)
    lookup.add_argument("--cache-ttl-hours", type=float, default=24.0)
    lookup.add_argument("--no-cache", action="store_true")
    lookup.add_argument("--output", type=Path)
    lookup.set_defaults(handler=handle_lookup)

    history = subparsers.add_parser("history", help="Manage optional recommendation history")
    history_sub = history.add_subparsers(dest="history_command", required=True)

    history_filter = history_sub.add_parser(
        "filter", help="Filter unchanged seen papers from a candidate payload"
    )
    history_filter.add_argument("--history-file", type=Path, required=True)
    history_filter.add_argument("--input", type=Path, required=True)
    history_filter.add_argument("--output", type=Path)
    history_filter.add_argument("--include-seen", action="store_true")
    history_filter.set_defaults(handler=handle_history_filter)

    history_mark = history_sub.add_parser(
        "mark", help="Record papers that were actually recommended"
    )
    history_mark.add_argument("--history-file", type=Path, required=True)
    history_mark.add_argument(
        "--paper",
        action="append",
        default=[],
        metavar="TOPIC_ID=ARXIV_ID",
    )
    history_mark.add_argument(
        "--selected-file",
        type=Path,
        help="JSON list or {selections:[{topic_id,source_id}]}",
    )
    history_mark.set_defaults(handler=handle_history_mark)

    history_clear = history_sub.add_parser(
        "clear", help="Clear selected history entries or the entire history file"
    )
    history_clear.add_argument("--history-file", type=Path, required=True)
    history_clear.add_argument("--paper", action="append", default=[])
    history_clear.add_argument("--all", action="store_true")
    history_clear.set_defaults(handler=handle_history_clear)

    validate = subparsers.add_parser(
        "validate-report", help="Validate the fixed Markdown brief layout"
    )
    validate.add_argument("--input", type=Path, required=True)
    validate.add_argument("--topic", action="append", default=[], required=True)
    validate.set_defaults(handler=handle_validate_report)
    return parser


def _custom_args_present(args: argparse.Namespace) -> bool:
    return bool(
        args.query
        or args.keyword
        or args.required_group
        or args.positive
        or args.negative
        or args.exclude
        or args.category
    )


def _write_json(payload: Any, output: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text + "\n", encoding="utf-8")
        print(str(output))
    else:
        print(text)


def _build_cache(args: argparse.Namespace) -> ResponseCache | None:
    if args.no_cache:
        return None
    cache_dir = args.cache_dir or (
        Path.cwd() / "tmp" / "codex-session-arxiv-research-brief" / "cache"
    )
    cache = ResponseCache(
        cache_dir,
        ttl_seconds=max(1, int(args.cache_ttl_hours * 3600)),
    )
    cache.cleanup()
    return cache


def handle_search(args: argparse.Namespace) -> int:
    custom = _custom_args_present(args)
    if custom and (args.profile or args.profile_file):
        raise ValueError("Custom query options cannot be combined with a profile")
    if custom:
        topics = [
            build_custom_topic(
                topic_id=args.topic_id,
                name=args.name,
                query=args.query,
                keywords=args.keyword,
                required_groups=args.required_group,
                positive_terms=args.positive,
                negative_terms=args.negative,
                exclude_terms=args.exclude,
                categories=args.category,
                min_score=args.min_score,
            )
        ]
    else:
        topics = load_profile(
            profile=args.profile or ("multimodal" if not args.profile_file else None),
            profile_file=args.profile_file,
        )
    window = DateWindow.from_values(
        days=args.days,
        start=args.start,
        end=args.end,
    )
    cache = _build_cache(args)
    history = HistoryStore(args.history_file) if args.history_file else None
    pipeline = BriefPipeline(
        adapter=ArxivOfficialAdapter(cache=cache),
        history=history,
    )
    payload = pipeline.run(
        topics=topics,
        window=window,
        candidate_limit=args.candidate_limit,
        papers_per_topic=args.papers_per_topic,
        page_size=args.page_size,
        max_results_per_topic=args.max_results_per_topic,
        max_pages=args.max_pages,
        include_seen=args.include_seen,
    )
    _write_json(payload, args.output)
    summary = payload["summary"]
    if summary["failed_topic_count"] == summary["topic_count"]:
        return 2
    return 0


def normalize_arxiv_identifier(value: str) -> str | None:
    text = value.strip().strip("<>")
    if not text:
        return None
    if text.lower().startswith("arxiv:"):
        text = text.split(":", 1)[1].strip()
    parsed = urllib.parse.urlparse(text)
    if parsed.scheme and parsed.netloc:
        if not parsed.netloc.lower().endswith("arxiv.org"):
            return None
        parts = [
            urllib.parse.unquote(part)
            for part in parsed.path.split("/")
            if part
        ]
        if len(parts) < 2 or parts[0].lower() not in {"abs", "html", "pdf"}:
            return None
        text = parts[1]
    else:
        for prefix in ("abs/", "html/", "pdf/"):
            if text.lower().startswith(prefix):
                text = text.split("/", 1)[1]
                break
        text = urllib.parse.unquote(text.split("?", 1)[0].split("#", 1)[0])
    if text.lower().endswith(".pdf"):
        text = text[:-4]
    text = text.strip().rstrip("/")
    return text if ARXIV_ID_RE.fullmatch(text) else None


def _canonical_lookup_key(source_id: str) -> str:
    return re.sub(r"v\d+$", "", source_id, flags=re.IGNORECASE).lower()


def _lookup_candidate(paper: Any) -> dict[str, Any]:
    return {
        "paper": paper.to_dict(),
        "topic_id": "specified-papers",
        "topic_name": "指定 arXiv 论文",
        "relevance_score": 0,
        "relevance_reasons": ["user-specified arXiv ID"],
        "evidence_hint": [],
        "history_status": "new",
    }


def handle_lookup(args: argparse.Namespace) -> int:
    parsed_inputs: list[tuple[str, str]] = []
    unique_ids: list[str] = []
    seen_ids: set[str] = set()
    missing_inputs: list[dict[str, str]] = []
    for raw in args.items:
        normalized = normalize_arxiv_identifier(raw)
        if normalized is None:
            missing_inputs.append(
                {
                    "input": raw,
                    "reason": "unrecognized arXiv ID or URL",
                }
            )
            continue
        parsed_inputs.append((raw, normalized))
        lookup_key = normalized.lower()
        if lookup_key not in seen_ids:
            unique_ids.append(normalized)
            seen_ids.add(lookup_key)

    result = None
    found = []
    if unique_ids:
        adapter = ArxivOfficialAdapter(cache=_build_cache(args))
        result = adapter.lookup_by_ids(unique_ids)
        found = result.items

    by_source_id = {paper.source_id.lower(): paper for paper in found}
    by_canonical_id = {paper.canonical_id.lower(): paper for paper in found}
    candidates: list[dict[str, Any]] = []
    for raw, normalized in parsed_inputs:
        paper = by_source_id.get(normalized.lower()) or by_canonical_id.get(
            _canonical_lookup_key(normalized)
        )
        if paper is None:
            missing_inputs.append(
                {
                    "input": raw,
                    "normalized_id": normalized,
                    "reason": "not returned by arXiv API",
                }
            )
            continue
        candidates.append(_lookup_candidate(paper))

    fetched = len(found)
    unique_found = len({paper.canonical_id for paper in found})
    payload = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": ArxivOfficialAdapter.source_name,
        "metadata_only": True,
        "pdf_or_full_text_read": False,
        "date_window": None,
        "candidate_limit_per_topic": len(candidates),
        "requested_papers_per_topic": len(candidates),
        "missing_inputs": missing_inputs,
        "summary": {
            "topic_count": 1,
            "failed_topic_count": 0,
            "raw_fetched": fetched,
            "unique_across_topics": unique_found,
            "any_truncated": False,
        },
        "topics": [
            {
                "id": "specified-papers",
                "name": "指定 arXiv 论文",
                "query": result.query if result else "id_list:",
                "requested_papers": len(candidates),
                "candidates": candidates,
                "important_updates": [],
                "stats": {
                    "api_total_results": result.total_results if result else 0,
                    "fetched": fetched,
                    "unique": unique_found,
                    "eligible_before_history": len(candidates),
                    "candidate_count": len(candidates),
                    "update_count": 0,
                    "pages_fetched": result.pages_fetched if result else 0,
                    "network_pages": result.network_pages if result else 0,
                    "cached_pages": result.cached_pages if result else 0,
                    "truncated": False,
                },
                "error": None,
            }
        ],
    }
    _write_json(payload, args.output)
    return 0


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot read JSON: {path}") from exc


def handle_history_filter(args: argparse.Namespace) -> int:
    payload = _load_json(args.input)
    store = HistoryStore(args.history_file)
    for topic in payload.get("topics", []):
        topic_id = topic.get("id", "")
        for key in ("candidates", "important_updates"):
            visible = []
            for item in topic.get(key, []):
                source_id = item["paper"]["source_id"]
                status = store.status(topic_id, source_id)
                item["history_status"] = status
                if args.include_seen or status != "seen":
                    visible.append(item)
            topic[key] = visible
    _write_json(payload, args.output)
    return 0


def _selected_entries(args: argparse.Namespace) -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    for value in args.paper:
        topic_id, separator, source_id = value.partition("=")
        if not separator or not topic_id.strip() or not source_id.strip():
            raise ValueError(f"Expected TOPIC_ID=ARXIV_ID, got {value!r}")
        entries.append((topic_id.strip(), source_id.strip()))
    if args.selected_file:
        value = _load_json(args.selected_file)
        selections = value if isinstance(value, list) else value.get("selections", [])
        for selection in selections:
            entries.append((selection["topic_id"], selection["source_id"]))
    if not entries:
        raise ValueError("Provide at least one --paper or --selected-file")
    return entries


def handle_history_mark(args: argparse.Namespace) -> int:
    store = HistoryStore(args.history_file)
    entries = _selected_entries(args)
    for topic_id, source_id in entries:
        store.mark(topic_id, source_id)
    print(json.dumps({"marked": len(entries), "history_file": str(args.history_file)}))
    return 0


def handle_history_clear(args: argparse.Namespace) -> int:
    if args.all == bool(args.paper):
        raise ValueError("Use either --all or one or more --paper values")
    store = HistoryStore(args.history_file)
    removed = store.clear(None if args.all else args.paper)
    print(json.dumps({"removed": removed, "history_file": str(args.history_file)}))
    return 0


def handle_validate_report(args: argparse.Namespace) -> int:
    text = args.input.read_text(encoding="utf-8")
    errors = validate_report(text, args.topic)
    print(
        json.dumps(
            {"valid": not errors, "errors": errors},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if not errors else 1


def main(argv: list[str] | None = None) -> int:
    if sys.stdout.encoding != "utf-8" and hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer,
            encoding="utf-8",
            errors="replace",
        )
    if sys.stderr.encoding != "utf-8" and hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(
            sys.stderr.buffer,
            encoding="utf-8",
            errors="replace",
        )
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.handler(args))
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
        return 2
