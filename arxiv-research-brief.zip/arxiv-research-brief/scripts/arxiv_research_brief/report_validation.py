from __future__ import annotations

import re


REQUIRED_HEADINGS = (
    "## 检索范围与统计",
    "## 各方向速览",
    "## 重要更新",
    "## 跨方向趋势",
    "## 判断边界",
)

CARD_FIELDS = (
    "**元数据：**",
    "**刊会状态：**",
    "**研究问题：**",
    "**核心方法：**",
    "**摘要证据：**",
    "**阅读建议：**",
    "**风险与局限：**",
)


def validate_report(text: str, topic_names: list[str]) -> list[str]:
    errors: list[str] = []
    for heading in REQUIRED_HEADINGS:
        if heading not in text:
            errors.append(f"Missing heading: {heading}")
    for topic_name in topic_names:
        heading = f"## {topic_name}"
        if heading not in text:
            errors.append(f"Missing topic section: {heading}")
            continue
        section = _section(text, heading)
        cards = re.split(r"(?m)^###\s+\d+\.", section)[1:]
        if not cards:
            if "无达到相关性阈值的论文" not in section and "检索失败" not in section:
                errors.append(
                    f"{topic_name}: no paper cards and no explicit empty/failure notice"
                )
            continue
        for index, card in enumerate(cards, start=1):
            for field in CARD_FIELDS:
                if field not in card:
                    errors.append(f"{topic_name} card {index}: missing {field}")
    if re.search(r"(?i)\b(file://|本地文件|见附件)\b", text):
        errors.append("Report appears to replace chat content with a local file reference")
    return errors


def _section(text: str, heading: str) -> str:
    start = text.find(heading)
    if start < 0:
        return ""
    remainder = text[start + len(heading) :]
    next_heading = re.search(r"(?m)^##\s+", remainder)
    return remainder[: next_heading.start()] if next_heading else remainder
