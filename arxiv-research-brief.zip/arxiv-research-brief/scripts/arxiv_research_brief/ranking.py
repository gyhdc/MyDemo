from __future__ import annotations

from datetime import datetime

from .models import PaperRecord, RankedPaper, TopicSpec


EVIDENCE_PATTERNS = {
    "datasets": ("dataset", "benchmark"),
    "experiments": ("experiment", "evaluation", "empirical result"),
    "ablation": ("ablation",),
    "theory": ("theorem", "theoretical guarantee", "proof"),
    "code": ("code is available", "open-source", "github"),
    "real-world": ("real-world", "real world", "in-the-wild"),
}


def _normalized(text: str) -> str:
    return " ".join(text.lower().split())


def evidence_hints(paper: PaperRecord) -> list[str]:
    text = _normalized(paper.abstract)
    hints = [
        label
        for label, patterns in EVIDENCE_PATTERNS.items()
        if any(pattern in text for pattern in patterns)
    ]
    if "simulation" in text or "simulated" in text or "synthetic data" in text:
        hints.append("simulation")
    return hints


def score_paper(paper: PaperRecord, topic: TopicSpec) -> tuple[float, list[str]]:
    title = _normalized(paper.title)
    body = _normalized(f"{paper.title}\n{paper.abstract}")
    for group in topic.required_groups:
        if not any(_normalized(term) in body for term in group):
            return 0.0, []
    if any(_normalized(term) in body for term in topic.exclude_terms):
        return 0.0, []

    score = 0.0
    reasons: list[str] = []
    for term, weight in topic.positive_terms.items():
        normalized_term = _normalized(term)
        if normalized_term in body:
            title_hit = normalized_term in title
            score += float(weight) * (1.75 if title_hit else 1.0)
            reasons.append(("标题：" if title_hit else "摘要：") + term)
    for term, weight in topic.negative_terms.items():
        if _normalized(term) in body:
            score += float(weight)
            reasons.append(f"降权：{term}")
    return max(0.0, round(score, 3)), reasons


def _published_timestamp(value: str) -> float:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def rank_papers(
    papers: list[PaperRecord],
    topic: TopicSpec,
    candidate_limit: int,
) -> list[RankedPaper]:
    if candidate_limit < 1:
        raise ValueError("candidate_limit must be at least 1")
    ranked: list[RankedPaper] = []
    for paper in papers:
        score, reasons = score_paper(paper, topic)
        if score < topic.min_score:
            continue
        ranked.append(
            RankedPaper(
                paper=paper,
                topic_id=topic.id,
                topic_name=topic.name,
                relevance_score=score,
                relevance_reasons=reasons[:8],
                evidence_hint=evidence_hints(paper),
            )
        )
    ranked.sort(
        key=lambda item: (
            item.relevance_score,
            _published_timestamp(item.paper.published),
        ),
        reverse=True,
    )
    return ranked[:candidate_limit]
