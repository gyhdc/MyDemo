"""Deterministic arXiv metadata retrieval and candidate pre-screening."""

from .models import PaperRecord, RankedPaper, TopicSpec
from .query import DateWindow

__all__ = ["DateWindow", "PaperRecord", "RankedPaper", "TopicSpec"]
