from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import TopicSpec
from .query import keywords_to_query


SKILL_ROOT = Path(__file__).resolve().parents[2]
BUILTIN_PROFILES = {
    "multimodal": SKILL_ROOT / "references" / "multimodal-profile.json",
}


def load_profile(
    profile: str | None = None,
    profile_file: Path | None = None,
) -> list[TopicSpec]:
    if profile and profile_file:
        raise ValueError("--profile and --profile-file are mutually exclusive")
    if profile:
        path = BUILTIN_PROFILES.get(profile)
        if path is None:
            raise ValueError(
                f"Unknown profile {profile!r}; available: {', '.join(BUILTIN_PROFILES)}"
            )
    elif profile_file:
        path = profile_file
    else:
        raise ValueError("A profile or profile file is required")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"Profile file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid profile JSON: {path}") from exc
    topics_data = data.get("topics") if isinstance(data, dict) else None
    if not isinstance(topics_data, list) or not topics_data:
        raise ValueError("Profile must contain a non-empty topics array")
    topics = [TopicSpec.from_dict(item) for item in topics_data]
    ids = [topic.id for topic in topics]
    if len(ids) != len(set(ids)):
        raise ValueError("Profile topic ids must be unique")
    return topics


def parse_weighted_terms(values: list[str]) -> dict[str, float]:
    result: dict[str, float] = {}
    for value in values:
        term, separator, weight = value.rpartition("=")
        if not separator or not term.strip():
            raise ValueError(f"Expected TERM=WEIGHT, got {value!r}")
        result[term.strip()] = float(weight)
    return result


def build_custom_topic(
    topic_id: str,
    name: str,
    query: str | None,
    keywords: list[str],
    required_groups: list[str],
    positive_terms: list[str],
    negative_terms: list[str],
    exclude_terms: list[str],
    categories: list[str],
    min_score: float | None,
) -> TopicSpec:
    base_query = query.strip() if query else keywords_to_query(keywords)
    groups = [
        [term.strip() for term in value.split("|") if term.strip()]
        for value in required_groups
    ]
    if not groups and keywords:
        groups = [keywords]
    positives = parse_weighted_terms(positive_terms)
    if not positives:
        positives = {keyword: 4.0 for keyword in keywords}
    effective_min_score = (
        float(min_score)
        if min_score is not None
        else (0.0 if query and not keywords and not positives else 1.0)
    )
    return TopicSpec(
        id=topic_id.strip() or "custom-topic",
        name=name.strip() or "Custom topic",
        query=base_query,
        required_groups=groups,
        positive_terms=positives,
        negative_terms=parse_weighted_terms(negative_terms),
        exclude_terms=exclude_terms,
        categories=categories,
        min_score=effective_min_score,
    )
