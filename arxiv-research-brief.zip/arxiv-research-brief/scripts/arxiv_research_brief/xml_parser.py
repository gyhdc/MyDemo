from __future__ import annotations

import xml.etree.ElementTree as ET

from .models import PaperRecord, SearchPage


NAMESPACES = {
    "atom": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
    "opensearch": "http://a9.com/-/spec/opensearch/1.1/",
}


def _text(node: ET.Element, path: str) -> str:
    child = node.find(path, NAMESPACES)
    if child is None or not child.text:
        return ""
    return " ".join(child.text.split())


def _integer(root: ET.Element, path: str, default: int) -> int:
    value = _text(root, path)
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def parse_atom_feed(root: ET.Element) -> SearchPage:
    entries = root.findall("atom:entry", NAMESPACES)
    papers: list[PaperRecord] = []
    for entry in entries:
        source_url = _text(entry, "atom:id")
        if "/api/errors" in source_url:
            continue
        links = entry.findall("atom:link", NAMESPACES)
        abstract_url = next(
            (
                link.attrib.get("href", "")
                for link in links
                if link.attrib.get("rel") == "alternate"
            ),
            source_url,
        )
        pdf_url = next(
            (
                link.attrib.get("href", "")
                for link in links
                if link.attrib.get("type") == "application/pdf"
                or link.attrib.get("title") == "pdf"
            ),
            "",
        )
        authors: list[str] = []
        affiliations: list[str] = []
        for author in entry.findall("atom:author", NAMESPACES):
            name = _text(author, "atom:name")
            if name:
                authors.append(name)
            affiliation = _text(author, "arxiv:affiliation")
            if affiliation and affiliation not in affiliations:
                affiliations.append(affiliation)
        primary = entry.find("arxiv:primary_category", NAMESPACES)
        primary_category = primary.attrib.get("term", "") if primary is not None else ""
        categories = [
            node.attrib["term"]
            for node in entry.findall("atom:category", NAMESPACES)
            if node.attrib.get("term")
        ]
        source_id = source_url.rstrip("/").rsplit("/", 1)[-1]
        papers.append(
            PaperRecord(
                source="arxiv",
                source_id=source_id,
                title=_text(entry, "atom:title"),
                abstract=_text(entry, "atom:summary"),
                authors=authors,
                affiliations=affiliations,
                published=_text(entry, "atom:published"),
                updated=_text(entry, "atom:updated"),
                primary_category=primary_category,
                categories=categories,
                abstract_url=abstract_url.replace("http://", "https://", 1),
                pdf_url=pdf_url.replace("http://", "https://", 1),
                comment=_text(entry, "arxiv:comment"),
                journal_ref=_text(entry, "arxiv:journal_ref"),
                doi=_text(entry, "arxiv:doi"),
            )
        )
    return SearchPage(
        items=papers,
        total_results=_integer(root, "opensearch:totalResults", len(papers)),
        start_index=_integer(root, "opensearch:startIndex", 0),
        items_per_page=_integer(root, "opensearch:itemsPerPage", len(papers)),
    )
