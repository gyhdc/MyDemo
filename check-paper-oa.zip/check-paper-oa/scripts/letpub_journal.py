#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Query LetPub journal metadata by ISSN without third-party dependencies."""

from __future__ import annotations

import argparse
import html
import io
import json
import re
import sys
import time
from dataclasses import asdict, dataclass
from html.parser import HTMLParser
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import ProxyHandler, Request, build_opener


if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer, encoding="utf-8", errors="replace"
    )
if sys.stderr.encoding != "utf-8":
    sys.stderr = io.TextIOWrapper(
        sys.stderr.buffer, encoding="utf-8", errors="replace"
    )


LET_PUB_BASE_URL = "https://www.letpub.com.cn/index.php"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0 Safari/537.36 check-paper-oa/1.0"
)
ISSN_PATTERN = re.compile(r"^\d{4}-?\d{3}[\dX]$", re.IGNORECASE)


class LetPubLookupError(RuntimeError):
    """Raised when LetPub cannot be queried."""


@dataclass
class LetPubJournalInfo:
    query_issn: str
    issn: str = ""
    journal: str = ""
    rating: str = ""
    if_raw: str = ""
    impact_factor: str = ""
    cas_partition: str = ""
    subject: str = ""
    sci: str = ""
    oa: str = ""
    acceptance_rate: str = ""
    review_cycle: str = ""
    source_url: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class _LetPubTableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self.link_rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._row_links: list[str] | None = None
        self._cell: list[str] | None = None
        self._cell_link: list[str] | None = None
        self._skip_depth = 0
        self._anchor_depth = 0

    def _finish_cell(self) -> None:
        if self._row is not None and self._cell is not None:
            self._row.append(_compact_text("".join(self._cell)))
            if self._row_links is not None:
                self._row_links.append(
                    _compact_text("".join(self._cell_link or []))
                )
        self._cell = None
        self._cell_link = None

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        tag = tag.lower()
        if tag in {"script", "style"}:
            self._skip_depth += 1
            return
        if tag == "tr":
            self._row = []
            self._row_links = []
        elif tag in {"td", "th"} and self._row is not None:
            self._finish_cell()
            self._cell = []
            self._cell_link = []
        elif tag == "br" and self._cell is not None:
            self._cell.append(" ")
        elif tag == "a" and self._cell is not None:
            self._anchor_depth += 1

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style"} and self._skip_depth:
            self._skip_depth -= 1
            return
        if tag == "a" and self._anchor_depth:
            self._anchor_depth -= 1
            return
        if tag in {"td", "th"} and self._row is not None and self._cell is not None:
            self._finish_cell()
        elif tag == "tr" and self._row is not None:
            self._finish_cell()
            if self._row:
                self.rows.append(self._row)
                self.link_rows.append(self._row_links or [])
            self._row = None
            self._row_links = None
            self._cell = None
            self._cell_link = None

    def handle_data(self, data: str) -> None:
        if self._cell is not None and not self._skip_depth:
            self._cell.append(data)
            if self._anchor_depth and self._cell_link is not None:
                self._cell_link.append(data)


def _compact_text(value: str) -> str:
    value = html.unescape(value).replace("\xa0", " ")
    return re.sub(r"\s+", " ", value).strip()


def normalize_issn(value: str) -> str:
    cleaned = re.sub(r"[^0-9Xx]", "", value.strip())
    if len(cleaned) != 8:
        return ""
    normalized = f"{cleaned[:4]}-{cleaned[4:]}".upper()
    return normalized if ISSN_PATTERN.fullmatch(normalized) else ""


def parse_impact_factor(value: str) -> str:
    match = re.search(r"\bIF\s*:\s*([0-9]+(?:\.[0-9]+)?)", value)
    if match:
        return match.group(1)
    numeric = re.search(r"\b([0-9]+(?:\.[0-9]+)?)\b", value)
    return numeric.group(1) if numeric else ""


def build_letpub_url(issn: str) -> str:
    return LET_PUB_BASE_URL + "?" + urlencode(
        {
            "page": "journalapp",
            "view": "search",
            "searchissn": issn,
        }
    )


def parse_letpub_html(
    document: str,
    *,
    query_issn: str = "",
    source_url: str = "",
) -> LetPubJournalInfo | None:
    normalized_query = normalize_issn(query_issn) if query_issn else ""
    parser = _LetPubTableParser()
    parser.feed(document)
    for cells, links in zip(parser.rows, parser.link_rows):
        if len(cells) < 10:
            continue
        row_issn = normalize_issn(cells[0])
        if not row_issn:
            continue
        if normalized_query and row_issn != normalized_query:
            continue
        if_raw = cells[3]
        return LetPubJournalInfo(
            query_issn=normalized_query or row_issn,
            issn=row_issn,
            journal=links[1] or cells[1],
            rating=cells[2],
            if_raw=if_raw,
            impact_factor=parse_impact_factor(if_raw),
            cas_partition=cells[4],
            subject=cells[5],
            sci=cells[6],
            oa=cells[7],
            acceptance_rate=cells[8],
            review_cycle=cells[9],
            source_url=source_url,
        )
    return None


def query_letpub_by_issn(
    issn: str,
    *,
    timeout: float = 15,
    proxy: str | None = None,
    retries: int = 1,
    backoff: float = 0.5,
) -> LetPubJournalInfo | None:
    normalized = normalize_issn(issn)
    if not normalized:
        raise ValueError(f"Invalid ISSN: {issn!r}")
    url = build_letpub_url(normalized)
    handlers = [ProxyHandler({"http": proxy, "https": proxy} if proxy else {})]
    opener = build_opener(*handlers)
    last_error: Exception | None = None
    for attempt in range(retries + 1):
        request = Request(
            url,
            headers={
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                "User-Agent": USER_AGENT,
            },
        )
        try:
            with opener.open(request, timeout=timeout) as response:
                raw = response.read()
                encoding = response.headers.get_content_charset() or "utf-8"
            return parse_letpub_html(
                raw.decode(encoding, errors="replace"),
                query_issn=normalized,
                source_url=url,
            )
        except HTTPError as error:
            last_error = error
            retryable = error.code in {429, 500, 502, 503, 504}
            error.close()
        except (URLError, TimeoutError, OSError) as error:
            last_error = error
            retryable = True
        if not retryable or attempt >= retries:
            break
        if backoff:
            time.sleep(backoff * (2**attempt))
    raise LetPubLookupError(f"LetPub request failed for {normalized}: {last_error}")


def render_text(results: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    for result in results:
        query = result["query_issn"]
        lines.append(f"=== {query} ===")
        if result.get("error"):
            lines.append(f"  Error   : {result['error']}")
        elif not result.get("found"):
            lines.append("  Result  : 未找到")
        else:
            info = result["info"]
            labels = [
                ("ISSN", "issn"),
                ("Journal", "journal"),
                ("Rating", "rating"),
                ("CAS分区", "cas_partition"),
                ("学科", "subject"),
                ("SCI", "sci"),
                ("OA", "oa"),
                ("录用率", "acceptance_rate"),
                ("审稿周期", "review_cycle"),
                ("IF", "impact_factor"),
            ]
            for label, key in labels:
                lines.append(f"  {label:8s}: {info.get(key) or '—'}")
    return "\n".join(lines) + "\n"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Query LetPub journal partition, IF, and review cycle by ISSN."
    )
    parser.add_argument("issns", nargs="+", help="One or more ISSN values")
    parser.add_argument("--format", choices=("json", "text"), default="json")
    parser.add_argument("--timeout", type=float, default=15)
    parser.add_argument("--proxy", help="Proxy URL, for example http://127.0.0.1:7890")
    parser.add_argument("--retries", type=int, default=1)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    results: list[dict[str, Any]] = []
    exit_code = 0
    for issn in args.issns:
        normalized = normalize_issn(issn)
        result: dict[str, Any] = {
            "query_issn": normalized or issn,
            "found": False,
            "info": None,
            "error": "",
        }
        try:
            info = query_letpub_by_issn(
                issn,
                timeout=args.timeout,
                proxy=args.proxy,
                retries=args.retries,
            )
            if info:
                result["found"] = True
                result["info"] = info.to_dict()
        except (ValueError, LetPubLookupError) as error:
            result["error"] = str(error)
            exit_code = 1
        results.append(result)
    if args.format == "json":
        sys.stdout.write(json.dumps({"results": results}, ensure_ascii=False, indent=2))
        sys.stdout.write("\n")
    else:
        sys.stdout.write(render_text(results))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
