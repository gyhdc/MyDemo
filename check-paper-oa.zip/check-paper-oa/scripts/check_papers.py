#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Classify papers by OA status and summarize venue and CCF information."""

from __future__ import annotations

import argparse
import html
import io
import json
import os
import re
import sys
import time
import unicodedata
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, unquote, urlencode, urlsplit
from urllib.request import Request, urlopen


if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer, encoding="utf-8", errors="replace"
    )
if sys.stderr.encoding != "utf-8":
    sys.stderr = io.TextIOWrapper(
        sys.stderr.buffer, encoding="utf-8", errors="replace"
    )


USER_AGENT = "check-paper-oa/1.0"
DOI_PATTERN = re.compile(
    r"10\.\d{4,9}/[-._;()/:A-Z0-9]+",
    re.IGNORECASE,
)
EMPTY = "—"
PAPER_SUMMARY_HEADER = (
    "| 论文 | DOI | 期刊/会议·年份 | OA | CCF | 分区/级别 | IF | 审稿周期 | 录用率 |"
)
PAPER_SUMMARY_SEPARATOR = "|---|---|---|---|---|---|---|---|---|"
VENUE_SUMMARY_HEADER = (
    "| 期刊/会议 | 类型 | ISSN | OA | CCF | 分区/级别 | IF | 审稿周期 | 录用率 | 出版方 | OpenAlex指标 | APC |"
)
VENUE_SUMMARY_SEPARATOR = "|---|---|---|---|---|---|---|---|---|---|---|---|"
MARKDOWN_LINK_PATTERN = re.compile(r"^\[(?:\\.|[^\]\\])+\]\([^)\s]+\)$")
OA_LABELS = {
    "gold": "金色 OA",
    "hybrid": "混合 OA",
    "green": "绿色 OA",
    "bronze": "青铜 OA",
    "diamond": "钻石 OA",
    "open": "OA",
    "closed": "非 OA",
}
CCF_CATALOG_PATH = (
    Path(__file__).resolve().parents[1] / "references" / "ccf-2026.json"
)
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from letpub_journal import (  # noqa: E402
    LetPubJournalInfo,
    LetPubLookupError,
    normalize_issn,
    query_letpub_by_issn,
)


class MetadataError(RuntimeError):
    """Raised when a metadata source cannot be read."""


@dataclass
class PaperRecord:
    doi: str
    title: str = ""
    authors: list[str] = field(default_factory=list)
    publication_year: int | None = None
    publication_date: str = ""
    article_type: str = ""
    language: str = ""
    venue: str = ""
    venue_type: str = ""
    publisher: str = ""
    issns: list[str] = field(default_factory=list)
    volume: str = ""
    issue: str = ""
    pages: str = ""
    is_oa: bool | None = None
    oa_status: str = ""
    license: str = ""
    access_url: str = ""
    doi_url: str = ""
    ccf: dict[str, Any] = field(default_factory=dict)
    jcr: str = ""
    cas: str = ""
    sjr: str = ""
    impact_factor: str = ""
    letpub_rating: str = ""
    letpub_subject: str = ""
    letpub_sci: str = ""
    letpub_oa: str = ""
    acceptance_rate: str = ""
    review_cycle: str = ""
    letpub_url: str = ""
    sources: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def oa_group(self) -> str:
        if self.is_oa is True:
            return "oa"
        if self.is_oa is False:
            return "non_oa"
        return "unknown"

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["oa_group"] = self.oa_group
        return result


@dataclass
class VenueRecord:
    query: str
    name: str = ""
    venue_type: str = ""
    publisher: str = ""
    issns: list[str] = field(default_factory=list)
    is_oa: bool | None = None
    oa_status: str = ""
    source_url: str = ""
    ccf: dict[str, Any] = field(default_factory=dict)
    jcr: str = ""
    cas: str = ""
    sjr: str = ""
    impact_factor: str = ""
    letpub_rating: str = ""
    letpub_subject: str = ""
    letpub_sci: str = ""
    letpub_oa: str = ""
    acceptance_rate: str = ""
    review_cycle: str = ""
    letpub_url: str = ""
    works_count: int | None = None
    h_index: int | None = None
    i10_index: int | None = None
    two_year_mean_citedness: float | None = None
    is_in_doaj: bool | None = None
    apc_usd: int | float | None = None
    sources: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def oa_group(self) -> str:
        if self.is_oa is True:
            return "oa"
        if self.is_oa is False:
            return "non_oa"
        return "unknown"

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["oa_group"] = self.oa_group
        return result


class _DoiMetaParser(HTMLParser):
    META_NAMES = {
        "citation_doi",
        "dc.identifier",
        "dc.identifier.doi",
        "prism.doi",
        "doi",
    }

    def __init__(self) -> None:
        super().__init__()
        self.values: list[str] = []

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        attributes = {
            key.lower(): value or "" for key, value in attrs if key
        }
        if tag.lower() == "meta":
            name = (
                attributes.get("name")
                or attributes.get("property")
                or attributes.get("http-equiv")
                or ""
            ).lower()
            if name in self.META_NAMES and attributes.get("content"):
                self.values.append(attributes["content"])
        elif tag.lower() == "link" and attributes.get("href"):
            self.values.append(attributes["href"])


def extract_doi(value: str) -> str:
    decoded = html.unescape(unquote(value.strip()))
    decoded = re.sub(r"^doi\s*:\s*", "", decoded, flags=re.IGNORECASE)
    match = DOI_PATTERN.search(decoded)
    if not match:
        return ""
    doi = match.group(0).lower().rstrip(".,;:")
    while doi.endswith(")") and doi.count("(") < doi.count(")"):
        doi = doi[:-1]
    return doi


def extract_doi_from_html(document: str) -> str:
    parser = _DoiMetaParser()
    parser.feed(document)
    for value in parser.values:
        doi = extract_doi(value)
        if doi:
            return doi
    return extract_doi(document)


def resolve_input(
    value: str,
    *,
    timeout: float = 20,
    max_html_bytes: int = 1_000_000,
) -> str:
    doi = extract_doi(value)
    if doi:
        return doi

    parts = urlsplit(value.strip())
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        raise ValueError(f"Not a DOI or HTTP(S) article URL: {value!r}")
    if parts.path.lower().endswith(".pdf"):
        raise ValueError("PDF URLs are not accepted; provide the article page")

    request = Request(
        value,
        headers={
            "Accept": "text/html,application/xhtml+xml",
            "User-Agent": USER_AGENT,
        },
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get_content_type().lower()
            if content_type == "application/pdf":
                raise ValueError(
                    "PDF URLs are not accepted; provide the article page"
                )
            if content_type not in {"text/html", "application/xhtml+xml"}:
                raise ValueError(
                    f"Article URL returned unsupported content type: {content_type}"
                )
            declared_length = response.headers.get("Content-Length")
            if declared_length and int(declared_length) > max_html_bytes:
                raise ValueError("Article HTML exceeds the configured size limit")
            content = response.read(max_html_bytes + 1)
            if len(content) > max_html_bytes:
                raise ValueError("Article HTML exceeds the configured size limit")
            encoding = response.headers.get_content_charset() or "utf-8"
    except HTTPError as error:
        error.close()
        raise MetadataError(
            f"HTTP {error.code} while reading article URL"
        ) from error
    except URLError as error:
        raise MetadataError(f"Could not read article URL: {error}") from error

    doi = extract_doi_from_html(content.decode(encoding, errors="replace"))
    if not doi:
        raise ValueError("No DOI was found in the article page metadata")
    return doi


def collect_dois(
    values: list[str],
    input_file: Path | None,
    *,
    timeout: float,
    max_html_bytes: int,
) -> list[str]:
    raw_values = list(values)
    if input_file:
        raw_values.extend(
            line.strip()
            for line in input_file.read_text(
                encoding="utf-8-sig"
            ).splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    result = []
    seen = set()
    for value in raw_values:
        doi = resolve_input(
            value,
            timeout=timeout,
            max_html_bytes=max_html_bytes,
        )
        if doi not in seen:
            seen.add(doi)
            result.append(doi)
    return result


def collect_venue_queries(
    values: list[str],
    venue_file: Path | None,
) -> list[str]:
    raw_values = list(values)
    if venue_file:
        raw_values.extend(
            line.strip()
            for line in venue_file.read_text(
                encoding="utf-8-sig"
            ).splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    result = []
    seen = set()
    for value in raw_values:
        cleaned = value.strip()
        key = cleaned.casefold()
        if cleaned and key not in seen:
            seen.add(key)
            result.append(cleaned)
    return result


def fetch_json(
    url: str,
    *,
    timeout: float,
    retries: int = 2,
    backoff: float = 0.5,
) -> dict[str, Any]:
    last_error: Exception | None = None
    for attempt in range(retries + 1):
        request = Request(
            url,
            headers={"Accept": "application/json", "User-Agent": USER_AGENT},
        )
        retryable = True
        try:
            with urlopen(request, timeout=timeout) as response:
                return json.load(response)
        except HTTPError as error:
            last_error = error
            retryable = error.code in {429, 500, 502, 503, 504}
            error.close()
            message = f"HTTP {error.code} from metadata service"
        except (URLError, TimeoutError, json.JSONDecodeError) as error:
            last_error = error
            message = f"Could not read metadata service: {error}"
        if not retryable or attempt >= retries:
            raise MetadataError(message) from last_error
        if backoff:
            time.sleep(backoff * (2**attempt))
    raise MetadataError("Could not read metadata service")


def query_openalex(
    doi: str,
    *,
    timeout: float,
    api_key: str | None,
) -> dict[str, Any]:
    work_id = quote(f"doi:{doi}", safe=":")
    url = f"https://api.openalex.org/works/{work_id}"
    if api_key:
        url += "?" + urlencode({"api_key": api_key})
    return fetch_json(url, timeout=timeout)


OPENALEX_SOURCE_SELECT = ",".join(
    [
        "id",
        "display_name",
        "issn",
        "issn_l",
        "host_organization_name",
        "type",
        "works_count",
        "is_oa",
        "is_in_doaj",
        "apc_usd",
        "summary_stats",
    ]
)


def query_openalex_sources(
    query: str,
    *,
    venue_type: str = "any",
    timeout: float,
    api_key: str | None,
    per_page: int = 10,
) -> list[dict[str, Any]]:
    params = {
        "search": query,
        "per-page": str(per_page),
        "select": OPENALEX_SOURCE_SELECT,
    }
    filters = []
    if venue_type in {"journal", "conference"}:
        filters.append(f"type:{venue_type}")
    if filters:
        params["filter"] = ",".join(filters)
    if api_key:
        params["api_key"] = api_key
    payload = fetch_json(
        "https://api.openalex.org/sources?" + urlencode(params),
        timeout=timeout,
    )
    results = payload.get("results")
    return [item for item in results if isinstance(item, dict)] if isinstance(results, list) else []


def query_crossref(
    doi: str,
    *,
    timeout: float,
    contact_email: str | None,
) -> dict[str, Any]:
    url = f"https://api.crossref.org/works/{quote(doi, safe='')}"
    if contact_email:
        url += "?" + urlencode({"mailto": contact_email})
    payload = fetch_json(url, timeout=timeout)
    message = payload.get("message")
    if not isinstance(message, dict):
        raise MetadataError("Crossref response has no work record")
    return message


def query_unpaywall(
    doi: str,
    *,
    timeout: float,
    contact_email: str,
) -> dict[str, Any]:
    url = (
        f"https://api.unpaywall.org/v2/{quote(doi, safe='')}?"
        + urlencode({"email": contact_email})
    )
    return fetch_json(url, timeout=timeout)


def _first_text(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        for item in value:
            if isinstance(item, str) and item.strip():
                return item.strip()
    return ""


def _all_text(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, list):
        return [
            item.strip()
            for item in value
            if isinstance(item, str) and item.strip()
        ]
    return []


def _deduplicate(values: list[str]) -> list[str]:
    result = []
    seen = set()
    for value in values:
        cleaned = value.strip()
        key = cleaned.casefold()
        if cleaned and key not in seen:
            seen.add(key)
            result.append(cleaned)
    return result


def _crossref_authors(record: dict[str, Any]) -> list[str]:
    result = []
    for author in record.get("author") or []:
        if not isinstance(author, dict):
            continue
        name = " ".join(
            value.strip()
            for value in (
                str(author.get("given") or ""),
                str(author.get("family") or ""),
            )
            if value.strip()
        )
        if name:
            result.append(name)
    return result


def _openalex_authors(record: dict[str, Any]) -> list[str]:
    result = []
    for authorship in record.get("authorships") or []:
        author = authorship.get("author") if isinstance(authorship, dict) else {}
        name = author.get("display_name") if isinstance(author, dict) else ""
        if isinstance(name, str) and name.strip():
            result.append(name.strip())
    return result


def _crossref_date(record: dict[str, Any]) -> tuple[int | None, str]:
    for key in ("published", "published-online", "published-print", "issued"):
        container = record.get(key)
        parts = container.get("date-parts") if isinstance(container, dict) else None
        if not parts or not isinstance(parts[0], list) or not parts[0]:
            continue
        values = parts[0]
        year = values[0] if isinstance(values[0], int) else None
        date = "-".join(str(value).zfill(2) for value in values)
        return year, date
    return None, ""


def _source_info(openalex: dict[str, Any] | None) -> dict[str, Any]:
    primary = (openalex or {}).get("primary_location")
    source = primary.get("source") if isinstance(primary, dict) else None
    return source if isinstance(source, dict) else {}


def _metadata_issns(
    crossref: dict[str, Any] | None,
    openalex: dict[str, Any] | None,
) -> list[str]:
    source = _source_info(openalex)
    return _deduplicate(
        [
            *[
                item
                for item in (crossref or {}).get("ISSN") or []
                if isinstance(item, str)
            ],
            *[
                item
                for item in source.get("issn") or []
                if isinstance(item, str)
            ],
        ]
    )


def _venue_candidates(
    crossref: dict[str, Any] | None,
    openalex: dict[str, Any] | None,
) -> list[str]:
    event = (crossref or {}).get("event")
    event_name = event.get("name") if isinstance(event, dict) else ""
    source = _source_info(openalex)
    return _deduplicate(
        [
            *_all_text((crossref or {}).get("container-title")),
            *_all_text((crossref or {}).get("short-container-title")),
            _first_text(event_name),
            _first_text(source.get("display_name")),
        ]
    )


def _detect_venue_type(
    crossref: dict[str, Any] | None,
    openalex: dict[str, Any] | None,
) -> str:
    work_type = _first_text((crossref or {}).get("type")).lower()
    if "proceedings" in work_type or "conference" in work_type:
        return "conference"
    source_type = _first_text(_source_info(openalex).get("type")).lower()
    if source_type in {"conference", "journal"}:
        return source_type
    if "journal" in work_type:
        return "journal"
    return ""


def _normalize_venue(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    normalized = normalized.replace("&", "and")
    return re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", normalized)


def _venue_variants(value: str) -> set[str]:
    raw_values = [re.split(r"[（(]\s*原", value, maxsplit=1)[0]]
    raw_values.extend(
        match.group(1)
        for match in re.finditer(r"[（(]\s*原\s*(.+?)[）)]", value)
    )
    variants = set()
    for raw_value in raw_values:
        base = _normalize_venue(raw_value)
        if not base:
            continue
        local_variants = {base, re.sub(r"(?:19|20)\d{2}", "", base)}
        for candidate in list(local_variants):
            for prefix in ("proceedingsofthe", "proceedingsof"):
                if candidate.startswith(prefix):
                    local_variants.add(candidate[len(prefix) :])
        for candidate in list(local_variants):
            for prefix in ("ieeeacm", "acm", "ieee", "the"):
                if (
                    candidate.startswith(prefix)
                    and len(candidate) > len(prefix) + 6
                ):
                    local_variants.add(candidate[len(prefix) :])
        variants.update(local_variants)
    return {variant for variant in variants if variant}


def _ccf_result(status: str, edition: str = "") -> dict[str, Any]:
    return {
        "status": status,
        "grade": "",
        "field": "",
        "venue_type": "",
        "abbreviation": "",
        "name": "",
        "publisher": "",
        "url": "",
        "edition": edition,
        "source_page": None,
    }


def match_ccf(
    venue_names: list[str],
    catalog: list[dict[str, Any]],
    *,
    venue_type: str = "",
) -> dict[str, Any]:
    edition = _first_text(catalog[0].get("edition")) if catalog else ""
    normalized_names = set().union(
        *(_venue_variants(name) for name in venue_names)
    )
    if not normalized_names:
        return _ccf_result("unknown", edition)
    if not catalog:
        return _ccf_result("unknown")

    candidates = [
        entry
        for entry in catalog
        if not venue_type or entry.get("venue_type") == venue_type
    ]
    exact = []
    for entry in candidates:
        entry_variants = _venue_variants(str(entry.get("name") or ""))
        entry_variants.update(
            _venue_variants(str(entry.get("abbreviation") or ""))
        )
        if normalized_names.intersection(entry_variants):
            exact.append(entry)

    matches = exact
    if not matches:
        containment = []
        for entry in candidates:
            entry_names = _venue_variants(str(entry.get("name") or ""))
            if any(
                len(name) >= 12
                and len(entry_name) >= 12
                and (name in entry_name or entry_name in name)
                for name in normalized_names
                for entry_name in entry_names
            ):
                containment.append(entry)
        unique = {
            (
                item.get("grade"),
                item.get("venue_type"),
                item.get("field"),
                item.get("name"),
            ): item
            for item in containment
        }
        matches = list(unique.values()) if len(unique) == 1 else []

    if len(matches) != 1:
        return _ccf_result("not_listed", edition)
    result = dict(matches[0])
    result["status"] = "listed"
    return result


def load_catalog(path: Path = CCF_CATALOG_PATH) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    entries = payload.get("entries")
    if not isinstance(entries, list):
        raise ValueError("CCF catalog has no entries array")
    return [entry for entry in entries if isinstance(entry, dict)]


def _creative_commons_license(crossref: dict[str, Any] | None) -> str:
    for item in (crossref or {}).get("license") or []:
        url = item.get("URL") if isinstance(item, dict) else ""
        if isinstance(url, str) and "creativecommons.org/" in url.lower():
            return url
    return ""


def _classify_oa(
    openalex: dict[str, Any] | None,
    crossref: dict[str, Any] | None,
    unpaywall: dict[str, Any] | None,
    warnings: list[str],
) -> tuple[bool | None, str]:
    evidence: list[tuple[str, bool, str]] = []
    open_access = (openalex or {}).get("open_access")
    if isinstance(open_access, dict) and isinstance(
        open_access.get("is_oa"), bool
    ):
        evidence.append(
            (
                "OpenAlex",
                open_access["is_oa"],
                str(open_access.get("oa_status") or ""),
            )
        )
    if unpaywall and isinstance(unpaywall.get("is_oa"), bool):
        evidence.append(
            (
                "Unpaywall",
                unpaywall["is_oa"],
                str(unpaywall.get("oa_status") or ""),
            )
        )
    if _creative_commons_license(crossref):
        evidence.append(("Crossref CC license", True, "open"))
    if not evidence:
        return None, ""
    values = {value for _, value, _ in evidence}
    if len(values) > 1:
        warnings.append(
            "OA status conflict: "
            + ", ".join(f"{name}={value}" for name, value, _ in evidence)
        )
        return None, ""
    if True in values:
        status = next((status for _, _, status in evidence if status), "open")
        return True, status
    status = next((status for _, _, status in evidence if status), "closed")
    return False, status


def _repository_url(openalex: dict[str, Any] | None) -> str:
    for location in (openalex or {}).get("locations") or []:
        if not isinstance(location, dict):
            continue
        source = location.get("source") or {}
        if isinstance(source, dict) and source.get("type") == "repository":
            url = location.get("landing_page_url") or location.get("pdf_url")
            if isinstance(url, str) and url:
                return url
    return ""


def _primary_landing_url(openalex: dict[str, Any] | None) -> str:
    primary = (openalex or {}).get("primary_location")
    url = primary.get("landing_page_url") if isinstance(primary, dict) else ""
    return url.strip() if isinstance(url, str) else ""


def _crossref_resource(crossref: dict[str, Any] | None) -> str:
    resource = (crossref or {}).get("resource")
    primary = resource.get("primary") if isinstance(resource, dict) else None
    url = primary.get("URL") if isinstance(primary, dict) else ""
    return url.strip() if isinstance(url, str) else ""


def _access_url(
    doi_url: str,
    is_oa: bool | None,
    openalex: dict[str, Any] | None,
    crossref: dict[str, Any] | None,
    unpaywall: dict[str, Any] | None,
) -> str:
    if is_oa:
        best = (openalex or {}).get("best_oa_location") or {}
        unpaywall_best = (unpaywall or {}).get("best_oa_location") or {}
        candidates = [
            _repository_url(openalex),
            best.get("landing_page_url"),
            _primary_landing_url(openalex),
            _crossref_resource(crossref),
            unpaywall_best.get("url"),
            (openalex or {}).get("open_access", {}).get("oa_url"),
            unpaywall_best.get("url_for_pdf"),
            best.get("pdf_url"),
        ]
        for candidate in candidates:
            if isinstance(candidate, str) and candidate:
                return candidate
    return _crossref_resource(crossref) or doi_url


def _letpub_payload(letpub: LetPubJournalInfo | dict[str, Any] | None) -> dict[str, Any]:
    if letpub is None:
        return {}
    if isinstance(letpub, dict):
        return letpub
    return letpub.to_dict()


def lookup_letpub_for_issns(
    issns: list[str],
    *,
    cache: dict[str, LetPubJournalInfo | None],
    timeout: float,
    proxy: str | None,
    warnings: list[str],
) -> LetPubJournalInfo | None:
    last_error = ""
    for issn in issns:
        normalized = normalize_issn(issn)
        if not normalized:
            continue
        if normalized not in cache:
            try:
                cache[normalized] = query_letpub_by_issn(
                    normalized,
                    timeout=timeout,
                    proxy=proxy,
                )
            except (ValueError, LetPubLookupError) as error:
                cache[normalized] = None
                last_error = str(error)
        if cache[normalized]:
            return cache[normalized]
    if issns:
        warnings.append(f"LetPub: {last_error or '未找到期刊信息'}")
    return None


def _source_issns(source: dict[str, Any] | None) -> list[str]:
    values: list[str] = []
    if not source:
        return values
    for item in source.get("issn") or []:
        if isinstance(item, str):
            normalized = normalize_issn(item)
            if normalized:
                values.append(normalized)
    issn_l = source.get("issn_l")
    if isinstance(issn_l, str):
        normalized = normalize_issn(issn_l)
        if normalized:
            values.append(normalized)
    return _deduplicate(values)


def _initialism(value: str) -> str:
    words = re.findall(r"[A-Za-z0-9]+", value)
    return "".join(word[0] for word in words).casefold()


def _publisher_matches(source: dict[str, Any], publisher: str) -> bool:
    if not publisher:
        return True
    source_publisher = _first_text(source.get("host_organization_name"))
    publisher_key = _normalize_venue(publisher)
    source_key = _normalize_venue(source_publisher)
    return (
        publisher_key in source_key
        or source_key in publisher_key
        or publisher_key.casefold() == _initialism(source_publisher)
    )


def _source_preference_score(query: str, source: dict[str, Any]) -> int:
    name = _first_text(source.get("display_name"))
    query_key = _normalize_venue(query)
    name_key = _normalize_venue(name)
    score = 0
    if name_key == query_key:
        score += 100
    elif query_key and query_key in name_key:
        score += 10
    if re.search(r"\b\d+(st|nd|rd|th)\b|\b20\d{2}\b|'\d{2}\b", name, re.I):
        score -= 8
    if re.match(r"\s*proceedings\s+of\s+the\s+\d", name, re.I):
        score -= 6
    return score


def _select_openalex_source(
    query: str,
    sources: list[dict[str, Any]],
    *,
    venue_type: str,
    publisher: str,
    warnings: list[str],
) -> dict[str, Any] | None:
    candidates = [
        item
        for item in sources
        if venue_type == "any" or _first_text(item.get("type")) == venue_type
    ]
    if publisher:
        publisher_matches = [
            item for item in candidates if _publisher_matches(item, publisher)
        ]
        if publisher_matches:
            candidates = publisher_matches
        else:
            warnings.append(f"OpenAlex: no candidate matched publisher {publisher!r}")
    if not candidates:
        warnings.append("OpenAlex: no source candidates found")
        return None

    query_key = _normalize_venue(query)
    exact = [
        item
        for item in candidates
        if _normalize_venue(_first_text(item.get("display_name"))) == query_key
    ]
    if exact:
        if len(exact) > 1:
            warnings.append("OpenAlex: multiple exact source matches; used first result")
        return exact[0]

    chosen = max(
        enumerate(candidates),
        key=lambda item: (_source_preference_score(query, item[1]), -item[0]),
    )[1]
    display_name = _first_text(chosen.get("display_name")) or "unknown source"
    warnings.append(f"OpenAlex: used non-exact source match {display_name!r}")
    return chosen


def build_venue_record(
    query: str,
    source: dict[str, Any] | None,
    catalog: list[dict[str, Any]],
    warnings: list[str],
    *,
    requested_type: str = "any",
    letpub: LetPubJournalInfo | dict[str, Any] | None = None,
) -> VenueRecord:
    warnings = list(warnings)
    display_name = _first_text((source or {}).get("display_name")) or query
    venue_type = _first_text((source or {}).get("type"))
    if not venue_type and requested_type in {"journal", "conference"}:
        venue_type = requested_type
    ccf_type = venue_type if venue_type in {"journal", "conference"} else ""
    ccf = match_ccf(
        _deduplicate([query, display_name]),
        catalog,
        venue_type=ccf_type,
    )
    issns = _source_issns(source)
    letpub_data = _letpub_payload(letpub)
    is_oa_value = (source or {}).get("is_oa")
    is_oa = is_oa_value if isinstance(is_oa_value, bool) else None
    summary_stats = (source or {}).get("summary_stats") or {}
    sources = []
    if source:
        sources.append("OpenAlex Sources")
    sources.append("CCF 2026 离线目录")
    if letpub_data:
        sources.append("LetPub")
    is_in_doaj = (source or {}).get("is_in_doaj")
    apc_usd = (source or {}).get("apc_usd")
    return VenueRecord(
        query=query,
        name=display_name,
        venue_type=venue_type,
        publisher=_first_text((source or {}).get("host_organization_name")),
        issns=issns,
        is_oa=is_oa,
        oa_status=("open" if is_oa is True else "closed" if is_oa is False else ""),
        source_url=_first_text((source or {}).get("id")),
        ccf=ccf,
        cas=_first_text(letpub_data.get("cas_partition")),
        impact_factor=_first_text(letpub_data.get("impact_factor")),
        letpub_rating=_first_text(letpub_data.get("rating")),
        letpub_subject=_first_text(letpub_data.get("subject")),
        letpub_sci=_first_text(letpub_data.get("sci")),
        letpub_oa=_first_text(letpub_data.get("oa")),
        acceptance_rate=_first_text(letpub_data.get("acceptance_rate")),
        review_cycle=_first_text(letpub_data.get("review_cycle")),
        letpub_url=_first_text(letpub_data.get("source_url")),
        works_count=summary_stats.get("works_count")
        if isinstance(summary_stats.get("works_count"), int)
        else (source or {}).get("works_count")
        if isinstance((source or {}).get("works_count"), int)
        else None,
        h_index=summary_stats.get("h_index")
        if isinstance(summary_stats.get("h_index"), int)
        else None,
        i10_index=summary_stats.get("i10_index")
        if isinstance(summary_stats.get("i10_index"), int)
        else None,
        two_year_mean_citedness=summary_stats.get("2yr_mean_citedness")
        if isinstance(summary_stats.get("2yr_mean_citedness"), (int, float))
        else None,
        is_in_doaj=is_in_doaj if isinstance(is_in_doaj, bool) else None,
        apc_usd=apc_usd if isinstance(apc_usd, (int, float)) else None,
        sources=sources,
        warnings=warnings,
    )


def fetch_venue_record(
    query: str,
    *,
    venue_type: str,
    publisher: str,
    timeout: float,
    openalex_api_key: str | None,
    catalog: list[dict[str, Any]],
    enrich_letpub: bool = True,
    letpub_timeout: float = 15,
    letpub_proxy: str | None = None,
    letpub_cache: dict[str, LetPubJournalInfo | None] | None = None,
) -> VenueRecord:
    warnings = []
    source = None
    try:
        candidates = query_openalex_sources(
            query,
            venue_type=venue_type,
            timeout=timeout,
            api_key=openalex_api_key,
        )
        source = _select_openalex_source(
            query,
            candidates,
            venue_type=venue_type,
            publisher=publisher,
            warnings=warnings,
        )
    except MetadataError as error:
        warnings.append(f"OpenAlex Sources: {error}")

    resolved_type = _first_text((source or {}).get("type"))
    if not resolved_type and venue_type in {"journal", "conference"}:
        resolved_type = venue_type
    letpub = None
    if enrich_letpub and resolved_type != "conference":
        letpub = lookup_letpub_for_issns(
            _source_issns(source),
            cache=letpub_cache if letpub_cache is not None else {},
            timeout=letpub_timeout,
            proxy=letpub_proxy,
            warnings=warnings,
        )
    return build_venue_record(
        query,
        source,
        catalog,
        warnings,
        requested_type=venue_type,
        letpub=letpub,
    )


def build_record(
    doi: str,
    openalex: dict[str, Any] | None,
    crossref: dict[str, Any] | None,
    unpaywall: dict[str, Any] | None,
    catalog: list[dict[str, Any]],
    warnings: list[str],
    letpub: LetPubJournalInfo | dict[str, Any] | None = None,
) -> PaperRecord:
    warnings = list(warnings)
    doi_url = f"https://doi.org/{doi}"
    source = _source_info(openalex)
    venue_names = _venue_candidates(crossref, openalex)
    venue_type = _detect_venue_type(crossref, openalex)
    ccf = match_ccf(venue_names, catalog, venue_type=venue_type)
    is_oa, oa_status = _classify_oa(
        openalex, crossref, unpaywall, warnings
    )
    crossref_year, crossref_date = _crossref_date(crossref or {})
    best_oa = (openalex or {}).get("best_oa_location") or {}
    unpaywall_best = (unpaywall or {}).get("best_oa_location") or {}
    license_value = (
        _first_text(best_oa.get("license"))
        or _first_text(unpaywall_best.get("license"))
        or _creative_commons_license(crossref)
    )
    publication_year = (
        crossref_year
        or (openalex or {}).get("publication_year")
        or (unpaywall or {}).get("year")
    )
    biblio = (openalex or {}).get("biblio") or {}
    sources = [
        name
        for name, payload in (
            ("OpenAlex", openalex),
            ("Crossref", crossref),
            ("Unpaywall", unpaywall),
        )
        if payload
    ]
    sources.append("CCF 2026 离线目录")
    letpub_data = _letpub_payload(letpub)
    if letpub_data:
        sources.append("LetPub")
    issns = _metadata_issns(crossref, openalex)
    return PaperRecord(
        doi=doi,
        title=_first_text((crossref or {}).get("title"))
        or _first_text((openalex or {}).get("display_name"))
        or _first_text((unpaywall or {}).get("title")),
        authors=_crossref_authors(crossref or {})
        or _openalex_authors(openalex or {}),
        publication_year=publication_year
        if isinstance(publication_year, int)
        else None,
        publication_date=crossref_date
        or _first_text((openalex or {}).get("publication_date")),
        article_type=_first_text((crossref or {}).get("type"))
        or _first_text((openalex or {}).get("type")),
        language=_first_text((crossref or {}).get("language"))
        or _first_text((openalex or {}).get("language")),
        venue=venue_names[0] if venue_names else "",
        venue_type=venue_type,
        publisher=_first_text((crossref or {}).get("publisher"))
        or _first_text(source.get("host_organization_name")),
        issns=issns,
        volume=_first_text((crossref or {}).get("volume"))
        or _first_text(biblio.get("volume")),
        issue=_first_text((crossref or {}).get("issue"))
        or _first_text(biblio.get("issue")),
        pages=_first_text((crossref or {}).get("page"))
        or _first_text(biblio.get("first_page")),
        is_oa=is_oa,
        oa_status=oa_status,
        license=license_value,
        access_url=_access_url(
            doi_url, is_oa, openalex, crossref, unpaywall
        ),
        doi_url=doi_url,
        ccf=ccf,
        cas=_first_text(letpub_data.get("cas_partition")),
        impact_factor=_first_text(letpub_data.get("impact_factor")),
        letpub_rating=_first_text(letpub_data.get("rating")),
        letpub_subject=_first_text(letpub_data.get("subject")),
        letpub_sci=_first_text(letpub_data.get("sci")),
        letpub_oa=_first_text(letpub_data.get("oa")),
        acceptance_rate=_first_text(letpub_data.get("acceptance_rate")),
        review_cycle=_first_text(letpub_data.get("review_cycle")),
        letpub_url=_first_text(letpub_data.get("source_url")),
        sources=sources,
        warnings=warnings,
    )


def fetch_record(
    doi: str,
    *,
    timeout: float,
    openalex_api_key: str | None,
    contact_email: str | None,
    catalog: list[dict[str, Any]],
    enrich_letpub: bool = True,
    letpub_timeout: float = 15,
    letpub_proxy: str | None = None,
    letpub_cache: dict[str, LetPubJournalInfo | None] | None = None,
) -> PaperRecord:
    warnings = []
    openalex = None
    crossref = None
    unpaywall = None
    try:
        openalex = query_openalex(
            doi, timeout=timeout, api_key=openalex_api_key
        )
    except MetadataError as error:
        warnings.append(f"OpenAlex: {error}")
    try:
        crossref = query_crossref(
            doi, timeout=timeout, contact_email=contact_email
        )
    except MetadataError as error:
        warnings.append(f"Crossref: {error}")
    if contact_email:
        try:
            unpaywall = query_unpaywall(
                doi, timeout=timeout, contact_email=contact_email
            )
        except MetadataError as error:
            warnings.append(f"Unpaywall: {error}")
    letpub = None
    venue_type = _detect_venue_type(crossref, openalex)
    if enrich_letpub and venue_type != "conference":
        letpub = lookup_letpub_for_issns(
            _metadata_issns(crossref, openalex),
            cache=letpub_cache if letpub_cache is not None else {},
            timeout=letpub_timeout,
            proxy=letpub_proxy,
            warnings=warnings,
        )
    return build_record(
        doi,
        openalex,
        crossref,
        unpaywall,
        catalog,
        warnings,
        letpub,
    )


def _escape_table(value: Any) -> str:
    if value is None or value == "":
        return EMPTY
    return str(value).replace("|", r"\|").replace("\r", " ").replace("\n", " ")


def _escape_link_label(value: Any) -> str:
    label = EMPTY if value is None or value == "" else str(value)
    return (
        label.replace("\\", r"\\")
        .replace("[", r"\[")
        .replace("]", r"\]")
        .replace("\r", " ")
        .replace("\n", " ")
    )


def _link(url: str, label: str) -> str:
    return f"[{_escape_link_label(label)}]({url})" if url else EMPTY


def _require_markdown_link(value: str, context: str) -> str:
    if not MARKDOWN_LINK_PATTERN.fullmatch(value):
        raise MetadataError(
            f"Markdown output validation failed: {context} must be a Markdown link."
        )
    return value


def _authors(authors: list[str], limit: int = 8) -> str:
    if not authors:
        return EMPTY
    if len(authors) <= limit:
        return ", ".join(authors)
    return f"{', '.join(authors[:limit])} 等（共 {len(authors)} 人）"


def _oa_label(record: PaperRecord) -> str:
    if record.is_oa is None:
        return "未知"
    return OA_LABELS.get(
        record.oa_status,
        "OA" if record.is_oa else "非 OA",
    )


def _ccf_label(record: PaperRecord, detailed: bool = False) -> str:
    status = record.ccf.get("status")
    if status == "listed":
        label = f"CCF {record.ccf.get('grade')}"
        if detailed:
            details = [
                "期刊" if record.ccf.get("venue_type") == "journal" else "会议",
                str(record.ccf.get("field") or ""),
                f"{record.ccf.get('edition')} 版",
            ]
            label += "（" + "；".join(item for item in details if item) + "）"
        return label
    if status == "not_listed":
        edition = record.ccf.get("edition")
        return f"未收录（{edition} 版）" if detailed and edition else "未收录"
    return "未知"


def _partition_label(record: PaperRecord) -> str:
    values = []
    if record.cas:
        cas_label = f"中科院 {record.cas}"
        if record.letpub_subject:
            cas_label = f"{cas_label}；{record.letpub_subject}"
        values.append(cas_label)
    if record.jcr:
        values.append(f"JCR {record.jcr}")
    if record.sjr:
        values.append(f"SJR {record.sjr}")
    if values:
        return "；".join(values)
    if record.venue_type == "conference":
        return "不适用（会议）"
    return EMPTY


def _journal_metric(value: str, record: PaperRecord) -> str:
    if value:
        return value
    if record.venue_type == "conference":
        return "不适用（会议）"
    return EMPTY


def _venue_year(record: PaperRecord) -> str:
    values = [
        value
        for value in (
            record.venue,
            str(record.publication_year) if record.publication_year else "",
        )
        if value
    ]
    return "；".join(values) or EMPTY


def _summary_table(records: list[PaperRecord]) -> str:
    lines = [PAPER_SUMMARY_HEADER, PAPER_SUMMARY_SEPARATOR]
    for record in records:
        paper_link = _require_markdown_link(
            _link(record.doi_url or record.access_url, record.title or record.doi),
            f"paper title for {record.doi}",
        )
        values = [
            paper_link,
            record.doi,
            _venue_year(record),
            _oa_label(record),
            _ccf_label(record),
            _partition_label(record),
            _journal_metric(record.impact_factor, record),
            _journal_metric(record.review_cycle, record),
            _journal_metric(record.acceptance_rate, record),
        ]
        lines.append("| " + " | ".join(_escape_table(item) for item in values) + " |")
    return "\n".join(lines)


def _issn_label(record: VenueRecord) -> str:
    return ", ".join(record.issns) if record.issns else EMPTY


def _venue_metric_label(record: VenueRecord) -> str:
    values = []
    if record.works_count is not None:
        values.append(f"works {record.works_count}")
    if record.h_index is not None:
        values.append(f"h {record.h_index}")
    if record.i10_index is not None:
        values.append(f"i10 {record.i10_index}")
    if record.two_year_mean_citedness is not None:
        values.append(f"2yr {record.two_year_mean_citedness:.2f}")
    return "；".join(values) if values else EMPTY


def _apc_label(record: VenueRecord) -> str:
    if record.apc_usd is None:
        return EMPTY
    return f"USD {record.apc_usd:g}"


def _venue_summary_table(records: list[VenueRecord]) -> str:
    lines = [VENUE_SUMMARY_HEADER, VENUE_SUMMARY_SEPARATOR]
    for record in records:
        venue_link = _link(record.source_url, record.name or record.query)
        if record.source_url:
            venue_link = _require_markdown_link(
                venue_link, f"venue name for {record.query}"
            )
        values = [
            venue_link,
            record.venue_type,
            _issn_label(record),
            _oa_label(record),
            _ccf_label(record),
            _partition_label(record),
            _journal_metric(record.impact_factor, record),
            _journal_metric(record.review_cycle, record),
            _journal_metric(record.acceptance_rate, record),
            record.publisher,
            _venue_metric_label(record),
            _apc_label(record),
        ]
        lines.append("| " + " | ".join(_escape_table(item) for item in values) + " |")
    return "\n".join(lines)


def _detail(record: PaperRecord, index: int) -> str:
    publication = record.publication_date or record.publication_year or EMPTY
    missing_ranking = (
        "不适用（会议）" if record.venue_type == "conference" else EMPTY
    )
    sources = "/".join(record.sources)
    if record.warnings:
        sources = "；".join([sources, *record.warnings]) if sources else "；".join(record.warnings)
    values = [
        ("DOI", _link(record.doi_url, record.doi)),
        ("作者", _authors(record.authors)),
        ("期刊/会议", record.venue or EMPTY),
        ("出版信息", str(publication)),
        ("类型/语言", "；".join(item for item in (record.article_type, record.language) if item) or EMPTY),
        ("卷期/页码", "；".join(item for item in (record.volume, record.issue, record.pages) if item) or EMPTY),
        ("OA", _oa_label(record)),
        ("许可", record.license or EMPTY),
        ("访问入口", _link(record.access_url, "打开")),
        ("CCF", _ccf_label(record, detailed=True)),
        ("分区/级别", _partition_label(record)),
        ("IF", record.impact_factor or missing_ranking),
        ("审稿周期", record.review_cycle or missing_ranking),
        ("LetPub评分", record.letpub_rating or missing_ranking),
        ("录用率", record.acceptance_rate or missing_ranking),
        ("LetPub学科", record.letpub_subject or missing_ranking),
        ("LetPub OA", record.letpub_oa or missing_ranking),
        ("LetPub入口", _link(record.letpub_url, "打开") if record.letpub_url else missing_ranking),
        ("JCR", record.jcr or missing_ranking),
        ("SJR", record.sjr or missing_ranking),
        ("来源/备注", sources or EMPTY),
    ]
    lines = [f"#### {index}. {record.title or record.doi}", ""]
    lines.extend(f"- **{label}**：{value}" for label, value in values)
    return "\n".join(lines)


def render_markdown(
    records: list[PaperRecord],
    *,
    include_details: bool = False,
    venue_records: list[VenueRecord] | None = None,
) -> str:
    venue_records = venue_records or []
    groups = {
        "oa": [record for record in records if record.oa_group == "oa"],
        "non_oa": [
            record for record in records if record.oa_group == "non_oa"
        ],
        "unknown": [
            record for record in records if record.oa_group == "unknown"
        ],
    }
    lines = []
    if records or not venue_records:
        lines.extend(
            [
                "# 论文 OA 与级别概览",
                "",
                f"- 查询时间（UTC）：{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')}",
                f"- 总计：{len(records)}",
                f"- OA：{len(groups['oa'])}",
                f"- 非 OA：{len(groups['non_oa'])}",
                f"- 未知：{len(groups['unknown'])}",
                "",
                "> CCF 使用 2026 年第七版离线目录；LetPub 按 ISSN 补充中科院分区、IF、审稿周期；JCR/SJR 未核实时不推断。",
            ]
        )
        for title, key in (
            ("开放获取（OA）", "oa"),
            ("非开放获取（非 OA）", "non_oa"),
            ("OA 状态未知", "unknown"),
        ):
            lines.extend(["", f"## {title}", ""])
            if not groups[key]:
                lines.append("无。")
                continue
            lines.append(_summary_table(groups[key]))
            if include_details:
                lines.extend(["", "### 详情", ""])
                lines.extend(
                    _detail(record, index)
                    for index, record in enumerate(groups[key], 1)
                )
    if venue_records:
        venue_groups = {
            "oa": [record for record in venue_records if record.oa_group == "oa"],
            "non_oa": [
                record for record in venue_records if record.oa_group == "non_oa"
            ],
            "unknown": [
                record for record in venue_records if record.oa_group == "unknown"
            ],
        }
        if lines:
            lines.append("")
        lines.extend(
            [
                "# 期刊/会议 OA 与级别概览",
                "",
                f"- 查询时间（UTC）：{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')}",
                f"- 总计：{len(venue_records)}",
                f"- OA：{len(venue_groups['oa'])}",
                f"- 非 OA：{len(venue_groups['non_oa'])}",
                f"- 未知：{len(venue_groups['unknown'])}",
                "",
                "> OpenAlex Sources 用于期刊/会议名解析；LetPub 按 ISSN 补充期刊中科院分区、IF、审稿周期；会议分区字段标记为不适用。",
            ]
        )
        for title, key in (
            ("开放获取（OA）", "oa"),
            ("非开放获取（非 OA）", "non_oa"),
            ("OA 状态未知", "unknown"),
        ):
            lines.extend(["", f"## {title}", ""])
            if not venue_groups[key]:
                lines.append("无。")
                continue
            lines.append(_venue_summary_table(venue_groups[key]))
    return "\n".join(lines) + "\n"


def render_json(
    records: list[PaperRecord],
    venue_records: list[VenueRecord] | None = None,
) -> str:
    groups = {
        key: [
            record.to_dict()
            for record in records
            if record.oa_group == key
        ]
        for key in ("oa", "non_oa", "unknown")
    }
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "total": len(records),
            "oa": len(groups["oa"]),
            "non_oa": len(groups["non_oa"]),
            "unknown": len(groups["unknown"]),
        },
        "groups": groups,
    }
    if venue_records is not None:
        venue_groups = {
            key: [
                record.to_dict()
                for record in venue_records
                if record.oa_group == key
            ]
            for key in ("oa", "non_oa", "unknown")
        }
        payload["venue_summary"] = {
            "total": len(venue_records),
            "oa": len(venue_groups["oa"]),
            "non_oa": len(venue_groups["non_oa"]),
            "unknown": len(venue_groups["unknown"]),
        }
        payload["venue_groups"] = venue_groups
    return json.dumps(payload, ensure_ascii=False, indent=2) + "\n"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Check paper OA status, venue OA status, and local CCF grade."
    )
    parser.add_argument("inputs", nargs="*", help="DOI values or article URLs")
    parser.add_argument("--input-file", type=Path)
    parser.add_argument(
        "--venue",
        action="append",
        default=[],
        help="Journal or conference name to look up with OpenAlex Sources.",
    )
    parser.add_argument(
        "--venue-file",
        type=Path,
        help="UTF-8 text file with one journal or conference name per line.",
    )
    parser.add_argument(
        "--venue-type",
        choices=("journal", "conference", "any"),
        default="any",
        help="Restrict venue lookup to journals, conferences, or either.",
    )
    parser.add_argument(
        "--publisher",
        default="",
        help="Optional publisher hint for venue disambiguation.",
    )
    parser.add_argument("--format", choices=("json", "markdown"), default="json")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--json-output", type=Path)
    parser.add_argument(
        "--details",
        action="store_true",
        help="Include per-paper vertical details in markdown output.",
    )
    parser.add_argument("--timeout", type=float, default=30)
    parser.add_argument("--max-html-bytes", type=int, default=1_000_000)
    parser.add_argument(
        "--ccf-catalog",
        type=Path,
        default=CCF_CATALOG_PATH,
    )
    parser.add_argument(
        "--openalex-api-key",
        default=os.environ.get("OPENALEX_API_KEY"),
    )
    parser.add_argument(
        "--contact-email",
        default=os.environ.get("UNPAYWALL_EMAIL"),
    )
    parser.add_argument(
        "--no-letpub",
        action="store_true",
        help="Do not enrich journals with LetPub partition, IF, and review cycle.",
    )
    parser.add_argument("--letpub-timeout", type=float, default=15)
    parser.add_argument(
        "--letpub-proxy",
        default=os.environ.get("LETPUB_PROXY"),
        help="Optional proxy URL for LetPub requests.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        dois = (
            collect_dois(
                args.inputs,
                args.input_file,
                timeout=args.timeout,
                max_html_bytes=args.max_html_bytes,
            )
            if args.inputs or args.input_file
            else []
        )
        venue_queries = collect_venue_queries(args.venue, args.venue_file)
        if not dois and not venue_queries:
            raise ValueError("Provide at least one DOI/article URL or --venue")
        catalog = load_catalog(args.ccf_catalog)
    except (OSError, UnicodeError, ValueError, MetadataError) as error:
        print(error, file=sys.stderr)
        return 2

    letpub_cache: dict[str, LetPubJournalInfo | None] = {}
    records = [
        fetch_record(
            doi,
            timeout=args.timeout,
            openalex_api_key=args.openalex_api_key,
            contact_email=args.contact_email,
            catalog=catalog,
            enrich_letpub=not args.no_letpub,
            letpub_timeout=args.letpub_timeout,
            letpub_proxy=args.letpub_proxy,
            letpub_cache=letpub_cache,
        )
        for doi in dois
    ]
    venue_records = [
        fetch_venue_record(
            query,
            venue_type=args.venue_type,
            publisher=args.publisher,
            timeout=args.timeout,
            openalex_api_key=args.openalex_api_key,
            catalog=catalog,
            enrich_letpub=not args.no_letpub,
            letpub_timeout=args.letpub_timeout,
            letpub_proxy=args.letpub_proxy,
            letpub_cache=letpub_cache,
        )
        for query in venue_queries
    ]
    json_venues = venue_records if venue_queries else None
    report = (
        render_json(records, json_venues)
        if args.format == "json"
        else render_markdown(
            records,
            include_details=args.details,
            venue_records=venue_records,
        )
    )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report, encoding="utf-8")
        print(args.output.resolve())
    else:
        sys.stdout.write(report)
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(
            render_json(records, json_venues),
            encoding="utf-8",
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
