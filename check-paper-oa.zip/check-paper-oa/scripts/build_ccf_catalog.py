#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Build an offline CCF venue catalog from the official PDF."""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


TYPE_HEADINGS = {
    "中国计算机学会推荐国际学术期刊": "journal",
    "中国计算机学会推荐国际学术会议": "conference",
}
GRADE_PATTERN = re.compile(r"[一二三]\s*、\s*([ABC])\s*类", re.IGNORECASE)
FIELD_PATTERN = re.compile(r"[（(]\s*([^（）()\n]+?)\s*[）)]")
EDITION_PATTERN = re.compile(r"[（(]\s*(\d{4})\s*年\s*[）)]")
YEAR_PATTERN = re.compile(r"(?<!\d)(20\d{2})(?!\d)")


def _clean_cell(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).split()).strip()


def _clean_url(value: Any) -> str:
    return re.sub(r"\s+", "", str(value or "")).strip()


def _is_header(row: list[Any]) -> bool:
    joined = "".join(_clean_cell(cell) for cell in row)
    return "序号" in joined and "简称" in joined and "全称" in joined


def parse_catalog_pages(
    pages: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    edition = ""
    venue_type = ""
    field = ""
    grade = ""
    records: list[dict[str, Any]] = []

    for page_number, page in enumerate(pages, 1):
        text = str(page.get("text") or "")
        edition_match = EDITION_PATTERN.search(text)
        if edition_match:
            edition = edition_match.group(1)
        elif "年" in text:
            year_match = YEAR_PATTERN.search(text)
            if year_match:
                edition = year_match.group(1)

        heading_found = False
        for heading, heading_type in TYPE_HEADINGS.items():
            if heading in text:
                venue_type = heading_type
                heading_found = True
                break

        if heading_found:
            fields = [
                match.group(1).strip()
                for match in FIELD_PATTERN.finditer(text)
                if not match.group(1).strip().endswith("年")
            ]
            if fields:
                field = fields[0]

        grade_matches = list(GRADE_PATTERN.finditer(text))
        if grade_matches:
            grade = grade_matches[-1].group(1).upper()

        if not all((edition, venue_type, field, grade)):
            continue

        for table in page.get("tables") or []:
            for row in table or []:
                if not isinstance(row, list) or _is_header(row):
                    continue
                if len(row) < 5 or not _clean_cell(row[0]).isdigit():
                    continue
                name = _clean_cell(row[2])
                if not name:
                    continue
                records.append(
                    {
                        "grade": grade,
                        "venue_type": venue_type,
                        "field": field,
                        "abbreviation": _clean_cell(row[1]),
                        "name": name,
                        "publisher": _clean_cell(row[3]),
                        "url": _clean_url(row[4]),
                        "edition": edition,
                        "source_page": page_number,
                    }
                )

    if not records:
        raise ValueError("No CCF venues were parsed")
    found_grades = {record["grade"] for record in records}
    if not found_grades.issuperset({"A", "B", "C"}):
        missing = sorted({"A", "B", "C"} - found_grades)
        raise ValueError(f"Catalog is missing grades: {missing}")
    return records


def extract_pdf_pages(pdf_path: Path) -> list[dict[str, Any]]:
    if not pdf_path.is_file():
        raise FileNotFoundError(pdf_path)
    try:
        import pdfplumber
    except ImportError as error:
        raise RuntimeError(
            "pdfplumber is required to rebuild the CCF catalog"
        ) from error

    pages = []
    with pdfplumber.open(pdf_path) as document:
        for page in document.pages:
            pages.append(
                {
                    "text": page.extract_text() or "",
                    "tables": page.extract_tables(),
                }
            )
    return pages


def write_catalog(
    records: list[dict[str, Any]],
    output_path: Path,
    source_pdf: Path,
) -> None:
    editions = {str(record.get("edition", "")) for record in records}
    if len(editions) != 1:
        raise ValueError("Catalog records do not share one edition")
    payload = {
        "edition": editions.pop(),
        "source": "中国计算机学会推荐国际学术会议和期刊目录（正式版）",
        "source_pdf": source_pdf.name,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "entry_count": len(records),
        "entries": records,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build an offline CCF venue catalog from the official PDF."
    )
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    records = parse_catalog_pages(extract_pdf_pages(args.pdf))
    write_catalog(records, args.output, args.pdf)
    print(f"Wrote {len(records)} entries to {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
