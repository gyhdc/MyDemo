---
name: check-paper-oa
description: Check one or more DOI values, DOI URLs, article-page links, journal names, or conference names for open-access status, then summarize essential paper and venue information, offline CCF 2026 grade, OpenAlex venue metadata, LetPub journal CAS partition/IF/review cycle, original paper links, and OA/paper or venue entries. Use when the user wants to separate OA from non-OA papers, inspect a paper's venue level, or directly look up journal/conference OA status, ISSN, CCF, LetPub, IF, review cycle, and basic venue metrics. Prefer the bundled CLI output and avoid web searches unless the user asks for specific missing information. Never download PDFs or bypass access controls.
---

# Check Paper OA

Use the bundled CLI as the primary source for deterministic DOI, OA,
bibliography, paper links, and CCF results. Browse or search only for
unresolved input links or information the user explicitly asks to verify.

## Run

```text
<PYTHON> <SKILL_ROOT>/scripts/check_papers.py <DOI_OR_URL...> --format markdown
```

Use `--input-file <PATH>` for one DOI or article URL per line. Use `--venue
<NAME>` for direct journal/conference lookup; repeat it for multiple venues or
use `--venue-file <PATH>` for one venue name per line. Use `--venue-type
journal|conference|any` and `--publisher <TEXT>` only when they help disambiguate
OpenAlex source matches. Use `--contact-email <EMAIL>` only when a real email is
already available; this enables Unpaywall. Do not invent an email.
Use `--format json` only when machine-readable data is needed; use
`--json-output <PATH>` when both final Markdown and JSON are needed.

The CLI automatically uses paper ISSN metadata to query LetPub for journal CAS
partition, impact factor, acceptance rate, and review cycle. Use `--no-letpub`
only when the user explicitly wants to avoid LetPub access. To query LetPub
directly by ISSN without creating a virtual environment:

```text
<PYTHON> <SKILL_ROOT>/scripts/letpub_journal.py <ISSN...> --format json
```

The CLI accepts:

- bare DOI values
- `doi.org` URLs or other URLs containing a DOI
- ordinary HTML article pages with DOI metadata
- direct journal or conference names through `--venue`

It rejects PDF URLs and never downloads article files.

## Workflow

1. Run the CLI once for all inputs, preserving input order. Use the CLI output
   as the source of truth; for final user-facing answers, reformat wide CLI
   tables into the compact Markdown shapes in `Output` unless the user asks for
   raw CLI output.
2. Use the CLI output as the default source for titles, authors, venues, dates,
   DOI/original paper links, OA status, access links, and CCF results. Do not
   re-search these fields when the CLI already returned them.
3. If an ordinary article page is blocked or has no machine-readable DOI, browse
   only that page or its exact title to identify the DOI, then rerun the CLI with
   the DOI. Do not browse DOI links that the CLI already resolved.
4. Trust OpenAlex and optional Unpaywall as paper-level OA evidence. For direct
   venue lookup, use OpenAlex Sources as the default venue metadata and OA
   evidence.
5. Keep conflicting or
   missing evidence in `OA 状态未知`; never treat unknown as non-OA.
6. Use each OA record's `access_url` as the clickable access entry. Do not open
   or download the PDF to test it.
7. Use the bundled `references/ccf-2026.json` result directly. It was generated
   from the official 2026 seventh-edition CCF catalog. Do not search the web for
   CCF grades.
8. Do not search the open web for JCR, SJR, publisher pages, titles, authors,
   dates, ISSN, publisher, OA type, or CCF by default. OpenAlex Sources lookup is
   part of the bundled CLI path for direct venue names. LetPub ISSN lookup is part
   of the bundled CLI path and may be used by default for journal 中科院分区、IF、
   录用率、审稿周期. Enrich missing rankings only when the user explicitly asks for
   paper level, partitions, rankings, or another specific missing field:
   - For journals, search once per unique journal for current JCR partitions that
      are still missing.
   - For conferences, mark journal partitions `不适用（会议）`; do not search.
   - Search SJR only when explicitly requested or when the user asks for an
     international alternative to JCR/中科院.
9. Reuse a ranking result for papers from the same venue. Never search once per
   paper when one venue-level lookup answers multiple papers.

## Ranking Rules

- Keep CCF, JCR, 中科院, and SJR separate.
- Include the ranking year or edition and a source link.
- Never derive JCR from impact factor, convert SJR into JCR, or guess a 中科院
  partition.
- Use `—` when a requested value cannot be verified.
- Treat `CCF 未收录` as different from `CCF 未知`.

## Output

Write Chinese Markdown in this order:

1. counts for total, OA, non-OA, and unknown
2. `## 开放获取（OA）`
3. `## 非开放获取（非 OA）`
4. `## OA 状态未知`

Group by the paper-level OA result returned by the CLI. Put all confirmed OA
papers in `开放获取（OA）`, including `金色 OA`, `混合 OA`, `绿色 OA`, `青铜 OA`,
`钻石 OA`, and generic `OA`.

For final user-facing answers, default to compact tables so chat windows remain
readable. CLI Markdown 只作为原始输出/复核材料. The agent may use CLI Markdown
or CLI JSON as the data source for reformatting, but 不得改写 OA、分区、IF、CCF 等事实字段, including DOI,
venue, date, publisher, APC, and OpenAlex/LetPub metrics.

Use this compact paper table shape for each non-empty group:

```markdown
| 论文 | DOI | 期刊/会议·年份 | OA | CCF/分区 | IF |
```

For direct venue lookup, use this compact table shape for each non-empty group:

```markdown
| 期刊/会议 | OA | CCF/分区 | IF | 出版方 | APC |
```

Combine CCF and partition/ranking in `CCF/分区`, for example `未收录；中科院
2区；大类：工程技术 小类：工程：土木` or `CCF A；不适用（会议）`. For journals, fill
partition, IF, review cycle, and acceptance rate from LetPub when an ISSN is
available. For conferences use `不适用（会议）`; otherwise use `—` for unavailable
or unverified values.

After each non-empty table, add `补充信息` for fields that would make the table
too wide:

- Paper lookup: review cycle, acceptance rate, access entry, license, source /
  notes, authors, and other user-requested details.
- Venue lookup: type, ISSN, review cycle, acceptance rate, OpenAlex metrics,
  LetPub entry, and other user-requested details.

Use the paper title itself as the DOI or publisher-page link. Keep a separate
plain `DOI` column immediately after `论文` so user-provided DOI inputs remain
easy to match. Do not add separate `原文链接` or `OA入口/论文页` columns in the
default answer. For venue lookup, use the OpenAlex source link on the venue name
when available.

Do not add long vertical details by default. Keep `补充信息` compact: one bullet
per paper or venue, and include only fields moved out of the table or explicitly
requested by the user. If the user asks for raw output or auditability, provide
the CLI Markdown table after the compact answer.

End with the source links actually used for ranking enrichment. The CLI source
names do not need redundant web searches.

## Rebuild CCF Data

Only rebuild when the official catalog changes:

```text
<PYTHON> <SKILL_ROOT>/scripts/build_ccf_catalog.py <CCF_PDF> --output <SKILL_ROOT>/references/ccf-2026.json
```

The builder requires `pdfplumber`. Verify representative A/B/C journal and
conference entries after rebuilding.

## Boundaries

- Never download PDFs.
- Never log in, solve CAPTCHAs, scrape protected pages, or bypass paywalls.
- Never expose API keys or contact email values.
- Do not search when the CLI and offline catalog already answer the request.
