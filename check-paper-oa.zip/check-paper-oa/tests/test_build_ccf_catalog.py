import importlib.util
import json
import tempfile
import unittest
from pathlib import Path


SCRIPT_PATH = (
    Path(__file__).resolve().parents[1] / "scripts" / "build_ccf_catalog.py"
)


def load_module(testcase):
    testcase.assertTrue(SCRIPT_PATH.exists(), "CCF catalog builder is missing")
    spec = importlib.util.spec_from_file_location("build_ccf_catalog", SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SAMPLE_PAGES = [
    {
        "text": (
            "中国计算机学会推荐国际学术会议和期刊目录\n"
            "（2026年）\n"
            "中国计算机学会推荐国际学术期刊\n"
            "（人工智能）\n"
            "一、A 类"
        ),
        "tables": [
            [
                ["序号", "期刊简称", "期刊全称", "出版社", "网址"],
                [
                    "1",
                    "JMLR",
                    "Journal of Machine Learning Research",
                    "MIT Press",
                    "http://dblp.org/journals/jmlr/",
                ],
                [
                    "2",
                    "TPAMI",
                    "IEEE Transactions on Pattern Analysis and\nMachine Intelligence",
                    "IEEE",
                    "http://dblp.org/journals/pami/",
                ],
            ]
        ],
    },
    {
        "text": "三、C 类",
        "tables": [
            [
                ["序号", "期刊简称", "期刊全称", "出版社", "网址"],
                [
                    "1",
                    "",
                    "Applied Intelligence",
                    "Springer",
                    "http://dblp.org/journals/apin/",
                ],
            ]
        ],
    },
    {
        "text": "中国计算机学会推荐国际学术会议\n（人工智能）\n二、B 类",
        "tables": [
            [
                ["序号", "会议简称", "会议全称", "出版社", "网址"],
                [
                    "1",
                    "IJCAI",
                    "International Joint Conference on\nArtificial Intelligence",
                    "IJCAI",
                    "http://dblp.org/conf/ijcai/",
                ],
            ]
        ],
    },
]


class CatalogParserTests(unittest.TestCase):
    def test_field_uses_heading_parentheses_not_later_alias(self):
        module = load_module(self)
        pages = [dict(page) for page in SAMPLE_PAGES]
        pages[0] = {
            **pages[0],
            "text": pages[0]["text"] + "\n（原 Some Venue Name）",
        }

        records = module.parse_catalog_pages(pages)

        self.assertEqual(records[0]["field"], "人工智能")

    def test_accepts_edition_year_split_from_parentheses(self):
        module = load_module(self)
        pages = [dict(page) for page in SAMPLE_PAGES]
        pages[0] = {
            **pages[0],
            "text": pages[0]["text"].replace("（2026年）", "（ 年）\n2026"),
        }

        records = module.parse_catalog_pages(pages)

        self.assertEqual(records[0]["edition"], "2026")

    def test_parses_journals_conferences_grades_and_wrapped_cells(self):
        module = load_module(self)

        records = module.parse_catalog_pages(SAMPLE_PAGES)

        self.assertEqual(len(records), 4)
        self.assertEqual(
            records[0],
            {
                "grade": "A",
                "venue_type": "journal",
                "field": "人工智能",
                "abbreviation": "JMLR",
                "name": "Journal of Machine Learning Research",
                "publisher": "MIT Press",
                "url": "http://dblp.org/journals/jmlr/",
                "edition": "2026",
                "source_page": 1,
            },
        )
        self.assertEqual(
            records[1]["name"],
            "IEEE Transactions on Pattern Analysis and Machine Intelligence",
        )
        self.assertEqual(records[2]["abbreviation"], "")
        self.assertEqual(records[2]["grade"], "C")
        self.assertEqual(records[3]["venue_type"], "conference")
        self.assertEqual(records[3]["grade"], "B")
        self.assertEqual(
            records[3]["name"],
            "International Joint Conference on Artificial Intelligence",
        )
        self.assertEqual(records[3]["source_page"], 3)

    def test_write_catalog_adds_source_metadata(self):
        module = load_module(self)
        records = module.parse_catalog_pages(SAMPLE_PAGES)

        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "ccf.json"
            module.write_catalog(
                records,
                output,
                source_pdf=Path("ccf-2026.pdf"),
            )
            payload = json.loads(output.read_text(encoding="utf-8"))

        self.assertEqual(payload["edition"], "2026")
        self.assertEqual(payload["source_pdf"], "ccf-2026.pdf")
        self.assertEqual(payload["entry_count"], 4)
        self.assertEqual(payload["entries"][0]["abbreviation"], "JMLR")


if __name__ == "__main__":
    unittest.main()
