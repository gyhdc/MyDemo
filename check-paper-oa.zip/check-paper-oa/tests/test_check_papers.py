import importlib.util
import json
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve().parents[1] / "scripts" / "check_papers.py"
LETPUB_SCRIPT_PATH = (
    Path(__file__).resolve().parents[1] / "scripts" / "letpub_journal.py"
)


def load_module(testcase):
    testcase.assertTrue(SCRIPT_PATH.exists(), "paper checker script is missing")
    spec = importlib.util.spec_from_file_location("check_papers", SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def load_letpub_module(testcase):
    testcase.assertTrue(LETPUB_SCRIPT_PATH.exists(), "LetPub script is missing")
    spec = importlib.util.spec_from_file_location("letpub_journal", LETPUB_SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sample_catalog():
    return [
        {
            "grade": "A",
            "venue_type": "journal",
            "field": "人工智能",
            "abbreviation": "JMLR",
            "name": "JournalofMachineLearningResearch",
            "publisher": "MITPress",
            "url": "https://dblp.org/db/journals/jmlr/",
            "edition": "2026",
            "source_page": 51,
        },
        {
            "grade": "A",
            "venue_type": "conference",
            "field": "数据库/数据挖掘/内容检索",
            "abbreviation": "SIGIR",
            "name": "InternationalACMSIGIRConferenceonResearchandDevelopmentinInformationRetrieval",
            "publisher": "ACM",
            "url": "https://dblp.org/db/conf/sigir/",
            "edition": "2026",
            "source_page": 35,
        },
        {
            "grade": "A",
            "venue_type": "conference",
            "field": "交叉/综合/新兴",
            "abbreviation": "WWW",
            "name": "TheWebConference （原InternationalWorldWideWebConference）",
            "publisher": "ACM",
            "url": "https://dblp.org/db/conf/www/",
            "edition": "2026",
            "source_page": 70,
        },
        {
            "grade": "C",
            "venue_type": "conference",
            "field": "数据库/数据挖掘/内容检索",
            "abbreviation": "APWeb",
            "name": "AsiaPacificWebConference",
            "publisher": "Springer",
            "url": "https://dblp.org/db/conf/apweb/",
            "edition": "2026",
            "source_page": 37,
        },
    ]


def sample_openalex(is_oa=True):
    return {
        "display_name": "OpenAlex fallback title",
        "publication_year": 2025,
        "publication_date": "2025-05-30",
        "language": "en",
        "type": "article",
        "open_access": {
            "is_oa": is_oa,
            "oa_status": "gold" if is_oa else "closed",
            "oa_url": "https://publisher.example/article" if is_oa else None,
        },
        "best_oa_location": {
            "landing_page_url": "https://oa.example/article",
            "license": "cc-by",
        }
        if is_oa
        else None,
        "locations": [
            {
                "is_oa": False,
                "landing_page_url": "https://repository.example/item",
                "source": {"type": "repository"},
            }
        ]
        if is_oa
        else [],
        "primary_location": {
            "landing_page_url": "https://publisher.example/primary",
            "source": {
                "display_name": "Journal of Machine Learning Research",
                "type": "journal",
                "issn": ["1532-4435"],
                "host_organization_name": "Microtome Publishing",
            }
        },
        "authorships": [
            {"author": {"display_name": "Alice Example"}},
            {"author": {"display_name": "Bob Example"}},
        ],
        "biblio": {"volume": "26", "issue": "1", "first_page": "1"},
    }


def sample_crossref():
    return {
        "DOI": "10.1234/example",
        "title": ["Crossref preferred title"],
        "author": [
            {"given": "Alice", "family": "Example"},
            {"given": "Bob", "family": "Example"},
        ],
        "published": {"date-parts": [[2025, 5, 30]]},
        "container-title": ["Journal of Machine Learning Research"],
        "short-container-title": ["JMLR"],
        "publisher": "Microtome Publishing",
        "ISSN": ["1532-4435"],
        "volume": "26",
        "issue": "1",
        "page": "1-20",
        "type": "journal-article",
        "language": "en",
        "URL": "https://doi.org/10.1234/example",
        "resource": {
            "primary": {"URL": "https://publisher.example/article"}
        },
    }


def sample_letpub():
    return {
        "query_issn": "1532-4435",
        "issn": "1532-4435",
        "journal": "JOURNAL OF MACHINE LEARNING RESEARCH",
        "rating": "8.9",
        "if_raw": "IF:6.0 h-index:312 CiteScore:11.2",
        "impact_factor": "6.0",
        "cas_partition": "1区",
        "subject": "大类：计算机科学小类：人工智能",
        "sci": "SCIE",
        "oa": "Yes",
        "acceptance_rate": "约25%",
        "review_cycle": "约6.0个月",
        "source_url": "https://www.letpub.com.cn/index.php?page=journalapp&view=search&searchissn=1532-4435",
    }


def sample_applied_letpub():
    return {
        "query_issn": "2076-3417",
        "issn": "2076-3417",
        "journal": "Applied Sciences-Basel",
        "rating": "7.6",
        "if_raw": "IF: 2.5 h-index: 23 CiteScore: 6.10",
        "impact_factor": "2.5",
        "cas_partition": "3区",
        "subject": "大类：综合性期刊 小类：化学：综合",
        "sci": "SCIE",
        "oa": "Yes",
        "acceptance_rate": "",
        "review_cycle": "11 Weeks",
        "source_url": "https://www.letpub.com.cn/index.php?page=journalapp&view=search&searchissn=2076-3417",
    }


def sample_openalex_source_journal():
    return {
        "id": "https://openalex.org/S4210205812",
        "display_name": "Applied Sciences",
        "issn": ["2076-3417"],
        "issn_l": "2076-3417",
        "host_organization_name": "Multidisciplinary Digital Publishing Institute",
        "type": "journal",
        "works_count": 89410,
        "is_oa": True,
        "is_in_doaj": True,
        "apc_usd": 2490,
        "summary_stats": {
            "2yr_mean_citedness": 3.339143345921694,
            "h_index": 221,
            "i10_index": 30179,
        },
    }


def sample_openalex_source_conference():
    return {
        "id": "https://openalex.org/S4306418959",
        "display_name": "International ACM SIGIR Conference on Research and Development in Information Retrieval",
        "issn": None,
        "issn_l": None,
        "host_organization_name": "ACM",
        "type": "conference",
        "works_count": 385,
        "is_oa": False,
        "is_in_doaj": False,
        "summary_stats": {
            "2yr_mean_citedness": 0.0,
            "h_index": 25,
            "i10_index": 78,
        },
    }


class _ArticleHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.endswith(".pdf"):
            body = b"%PDF-1.7"
            content_type = "application/pdf"
        else:
            body = (
                b'<html><head><meta name="citation_doi" '
                b'content="10.1145/3543507.3583551"></head></html>'
            )
            content_type = "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        return


class InputTests(unittest.TestCase):
    def test_extracts_doi_from_values_and_encoded_urls(self):
        module = load_module(self)

        self.assertEqual(
            module.extract_doi("10.1145/3543507.3583551"),
            "10.1145/3543507.3583551",
        )
        self.assertEqual(
            module.extract_doi(
                "https://doi.org/10.1145/3543507.3583551"
            ),
            "10.1145/3543507.3583551",
        )
        self.assertEqual(
            module.extract_doi(
                "https://publisher.test/article?doi=10.1145%2F3543507.3583551"
            ),
            "10.1145/3543507.3583551",
        )

    def test_extracts_doi_from_html_metadata(self):
        module = load_module(self)

        doi = module.extract_doi_from_html(
            '<meta charset="utf-8">'
            '<meta name="citation_doi" content="10.1145/3543507.3583551">'
        )

        self.assertEqual(doi, "10.1145/3543507.3583551")

    def test_resolves_ordinary_article_page_but_rejects_pdf(self):
        module = load_module(self)
        server = ThreadingHTTPServer(("127.0.0.1", 0), _ArticleHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            article_url = (
                f"http://127.0.0.1:{server.server_port}/article"
            )
            pdf_url = f"http://127.0.0.1:{server.server_port}/paper.pdf"
            self.assertEqual(
                module.resolve_input(article_url, timeout=2),
                "10.1145/3543507.3583551",
            )
            with self.assertRaisesRegex(ValueError, "PDF"):
                module.resolve_input(pdf_url, timeout=2)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


class LetPubTests(unittest.TestCase):
    def test_parses_letpub_search_table(self):
        module = load_letpub_module(self)
        document = """
        <table>
          <tr>
            <td>0013-7952</td>
            <td><a>ENGINEERING GEOLOGY</a><br><font>ENG GEOL</font>
            <td>8.5<script>rate.render({value:4.2});</script></td>
            <td>IF:8.4 h-index:192 CiteScore:13.2</td>
            <td>1区</td>
            <td>大类：工程技术 小类：工程：地质</td>
            <td>SCIE</td>
            <td>No</td>
            <td>50%</td>
            <td>约7.0个月</td>
          </tr>
        </table>
        """

        info = module.parse_letpub_html(
            document,
            query_issn="00137952",
            source_url="https://letpub.example/search",
        )

        self.assertIsNotNone(info)
        self.assertEqual(info.issn, "0013-7952")
        self.assertEqual(info.journal, "ENGINEERING GEOLOGY")
        self.assertEqual(info.cas_partition, "1区")
        self.assertEqual(info.impact_factor, "8.4")
        self.assertEqual(info.review_cycle, "约7.0个月")


class CcfTests(unittest.TestCase):
    def test_bundled_catalog_matches_representative_real_entries(self):
        module = load_module(self)
        catalog = module.load_catalog()

        jmlr = module.match_ccf(
            ["Journal of Machine Learning Research"],
            catalog,
            venue_type="journal",
        )
        www = module.match_ccf(
            ["Proceedings of the ACM Web Conference 2023"],
            catalog,
            venue_type="conference",
        )
        applied_intelligence = module.match_ccf(
            ["Applied Intelligence"],
            catalog,
            venue_type="journal",
        )

        self.assertEqual((jmlr["grade"], jmlr["abbreviation"]), ("A", "JMLR"))
        self.assertEqual((www["grade"], www["abbreviation"]), ("A", "WWW"))
        self.assertEqual(applied_intelligence["grade"], "C")

    def test_matches_conference_proceedings_wrapper_and_year(self):
        module = load_module(self)

        result = module.match_ccf(
            ["Proceedings of the ACM Web Conference 2023"],
            sample_catalog(),
            venue_type="conference",
        )

        self.assertEqual(result["status"], "listed")
        self.assertEqual(result["abbreviation"], "WWW")

    def test_matches_normalized_full_name_and_abbreviation(self):
        module = load_module(self)
        catalog = sample_catalog()

        journal = module.match_ccf(
            ["Journal of Machine Learning Research"],
            catalog,
            venue_type="journal",
        )
        conference = module.match_ccf(
            ["SIGIR"],
            catalog,
            venue_type="conference",
        )

        self.assertEqual(journal["status"], "listed")
        self.assertEqual(journal["grade"], "A")
        self.assertEqual(conference["field"], "数据库/数据挖掘/内容检索")

    def test_distinguishes_not_listed_from_unknown(self):
        module = load_module(self)

        not_listed = module.match_ccf(
            ["Applied Sciences"], sample_catalog(), venue_type="journal"
        )
        unknown = module.match_ccf([], sample_catalog(), venue_type="")

        self.assertEqual(not_listed["status"], "not_listed")
        self.assertEqual(unknown["status"], "unknown")


class RecordTests(unittest.TestCase):
    def test_uses_openalex_primary_landing_page_when_no_repository_exists(self):
        module = load_module(self)
        openalex = sample_openalex(True)
        openalex["locations"] = []
        openalex["best_oa_location"] = None
        openalex["open_access"]["oa_url"] = None

        record = module.build_record(
            "10.1234/example",
            openalex=openalex,
            crossref={key: value for key, value in sample_crossref().items() if key != "resource"},
            unpaywall=None,
            catalog=sample_catalog(),
            warnings=[],
        )

        self.assertEqual(
            record.access_url,
            "https://publisher.example/primary",
        )

    def test_merges_oa_bibliography_and_local_ccf(self):
        module = load_module(self)

        record = module.build_record(
            "10.1234/example",
            openalex=sample_openalex(True),
            crossref=sample_crossref(),
            unpaywall=None,
            catalog=sample_catalog(),
            warnings=[],
            letpub=sample_letpub(),
        )

        self.assertTrue(record.is_oa)
        self.assertEqual(record.oa_status, "gold")
        self.assertEqual(record.title, "Crossref preferred title")
        self.assertEqual(record.access_url, "https://repository.example/item")
        self.assertEqual(record.ccf["grade"], "A")
        self.assertEqual(record.cas, "1区")
        self.assertEqual(record.impact_factor, "6.0")
        self.assertEqual(record.review_cycle, "约6.0个月")

    def test_conflicting_oa_sources_are_unknown(self):
        module = load_module(self)

        record = module.build_record(
            "10.1234/example",
            openalex=sample_openalex(True),
            crossref=sample_crossref(),
            unpaywall={"is_oa": False, "oa_status": "closed"},
            catalog=sample_catalog(),
            warnings=[],
        )

        self.assertIsNone(record.is_oa)
        self.assertEqual(record.oa_group, "unknown")
        self.assertTrue(any("conflict" in item.lower() for item in record.warnings))


class VenueTests(unittest.TestCase):
    def test_prefers_generic_conference_source_over_numbered_proceedings(self):
        module = load_module(self)
        numbered = {
            **sample_openalex_source_conference(),
            "id": "https://openalex.org/S4363608773",
            "display_name": "Proceedings of the 45th International ACM SIGIR Conference on Research and Development in Information Retrieval",
            "works_count": 444,
        }
        generic = sample_openalex_source_conference()
        warnings = []

        selected = module._select_openalex_source(
            "SIGIR",
            [numbered, generic],
            venue_type="conference",
            publisher="",
            warnings=warnings,
        )

        self.assertEqual(selected["id"], "https://openalex.org/S4306418959")
        self.assertIn("non-exact", warnings[0])

    def test_fetches_journal_source_by_name_and_reuses_letpub_issn_lookup(self):
        module = load_module(self)
        original_query = module.query_openalex_sources
        original_lookup = module.lookup_letpub_for_issns
        calls = {}

        def fake_query(query, *, venue_type, timeout, api_key, per_page=10):
            calls["query"] = query
            calls["venue_type"] = venue_type
            return [sample_openalex_source_journal()]

        def fake_lookup(issns, **kwargs):
            calls["issns"] = issns
            return sample_applied_letpub()

        module.query_openalex_sources = fake_query
        module.lookup_letpub_for_issns = fake_lookup
        try:
            record = module.fetch_venue_record(
                "Applied Sciences",
                venue_type="journal",
                publisher="MDPI",
                timeout=2,
                openalex_api_key=None,
                catalog=sample_catalog(),
            )
        finally:
            module.query_openalex_sources = original_query
            module.lookup_letpub_for_issns = original_lookup

        self.assertEqual(calls["query"], "Applied Sciences")
        self.assertEqual(calls["venue_type"], "journal")
        self.assertEqual(calls["issns"], ["2076-3417"])
        self.assertTrue(record.is_oa)
        self.assertEqual(record.oa_group, "oa")
        self.assertEqual(record.issns, ["2076-3417"])
        self.assertEqual(record.cas, "3区")
        self.assertEqual(record.impact_factor, "2.5")
        self.assertEqual(record.review_cycle, "11 Weeks")
        self.assertEqual(record.works_count, 89410)
        self.assertEqual(record.h_index, 221)
        self.assertEqual(record.apc_usd, 2490)
        self.assertEqual(record.warnings, [])

    def test_builds_conference_venue_with_ccf_and_conference_metric_defaults(self):
        module = load_module(self)

        record = module.build_venue_record(
            "SIGIR",
            sample_openalex_source_conference(),
            sample_catalog(),
            [],
            requested_type="conference",
        )

        self.assertFalse(record.is_oa)
        self.assertEqual(record.venue_type, "conference")
        self.assertEqual(record.ccf["status"], "listed")
        self.assertEqual(record.ccf["abbreviation"], "SIGIR")
        markdown = module.render_markdown([], venue_records=[record])
        self.assertTrue(markdown.startswith("# 期刊/会议 OA 与级别概览"))
        self.assertIn(
            "| 期刊/会议 | 类型 | ISSN | OA | CCF | 分区/级别 | IF | 审稿周期 | 录用率 | 出版方 | OpenAlex指标 | APC |",
            markdown,
        )
        self.assertIn("不适用（会议）", markdown)
        payload = json.loads(module.render_json([], [record]))
        self.assertEqual(payload["venue_groups"]["non_oa"][0]["ccf"]["grade"], "A")
        self.assertEqual(payload["venue_summary"]["non_oa"], 1)


class RenderingTests(unittest.TestCase):
    def test_output_is_grouped_compact_and_preserves_rank_fields(self):
        module = load_module(self)
        oa = module.build_record(
            "10.1234/oa",
            sample_openalex(True),
            {**sample_crossref(), "DOI": "10.1234/oa"},
            None,
            sample_catalog(),
            [],
            sample_letpub(),
        )
        closed = module.build_record(
            "10.1234/closed",
            sample_openalex(False),
            {
                **sample_crossref(),
                "DOI": "10.1234/closed",
                "type": "proceedings-article",
                "container-title": ["Proceedings of the ACM Web Conference 2023"],
                "short-container-title": ["WWW"],
            },
            None,
            sample_catalog(),
            [],
        )
        unknown = module.build_record(
            "10.1234/unknown",
            None,
            {**sample_crossref(), "DOI": "10.1234/unknown"},
            None,
            sample_catalog(),
            ["OpenAlex unavailable"],
        )

        markdown = module.render_markdown([closed, unknown, oa])
        header = next(
            line for line in markdown.splitlines() if line.startswith("| 论文 |")
        )

        self.assertEqual(
            header,
            "| 论文 | DOI | 期刊/会议·年份 | OA | CCF | 分区/级别 | IF | 审稿周期 | 录用率 |",
        )
        self.assertLess(
            markdown.index("## 开放获取（OA）"),
            markdown.index("## 非开放获取"),
        )
        self.assertLess(
            markdown.index("## 非开放获取"),
            markdown.index("## OA 状态未知"),
        )
        self.assertIn(
            "| [Crossref preferred title](https://doi.org/10.1234/oa) | 10.1234/oa | Journal of Machine Learning Research；2025 | 金色 OA | CCF A | 中科院 1区；大类：计算机科学小类：人工智能 | 6.0 | 约6.0个月 | 约25% |",
            markdown,
        )
        self.assertIn("约25%", markdown)
        self.assertNotIn("### 详情", markdown)
        detailed_markdown = module.render_markdown(
            [closed, unknown, oa],
            include_details=True,
        )
        self.assertIn("- **CCF**：CCF A", detailed_markdown)
        self.assertIn(
            "- **分区/级别**：中科院 1区；大类：计算机科学小类：人工智能",
            detailed_markdown,
        )
        self.assertIn("- **IF**：6.0", detailed_markdown)
        self.assertIn("- **审稿周期**：约6.0个月", detailed_markdown)
        self.assertIn("- **SJR**：—", detailed_markdown)
        conference_detail = detailed_markdown[
            detailed_markdown.index("#### 1. Crossref preferred title", detailed_markdown.index("## 非开放获取"))
            :
        ]
        self.assertIn("- **分区/级别**：不适用（会议）", conference_detail)
        self.assertIn("- **IF**：不适用（会议）", conference_detail)
        self.assertIn("- **审稿周期**：不适用（会议）", conference_detail)
        self.assertIn("- **JCR**：不适用（会议）", conference_detail)
        self.assertIn("- **SJR**：不适用（会议）", conference_detail)
        self.assertNotIn("下载 PDF", detailed_markdown)

        payload = json.loads(module.render_json([oa]))
        self.assertEqual(payload["groups"]["oa"][0]["ccf"]["grade"], "A")
        self.assertEqual(
            payload["groups"]["oa"][0]["authors"],
            ["Alice Example", "Bob Example"],
        )
        self.assertEqual(payload["groups"]["oa"][0]["impact_factor"], "6.0")


if __name__ == "__main__":
    unittest.main()
